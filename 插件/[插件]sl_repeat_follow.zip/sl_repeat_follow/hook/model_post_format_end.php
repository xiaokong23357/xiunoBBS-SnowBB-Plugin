<?php exit;
$post['floormanage'] = forum_access_mod($thread['fid'], $gid, 'allowdelete');
?>