<?php
!defined('DEBUG') AND exit('Access Denied.');
if ($method == 'GET') {
    $popup = kv_get('aitu_baidutui');
    $url = $popup['url'];
    $urls = $popup['urls'];
    $site = $popup['site'];
    $thread = $popup['thread'];
    $htm = $popup['htm'];
    include _include(APP_PATH . 'plugin/aitu_baidutui/setting.htm');
} else {
    $url = param('url');
    $urls = param('urls');
    $site = param('site');
    $thread = param('thread');
    $htm = param('htm');
    $popup = array();
    $popup['url'] = $url;
    $popup['urls'] = $urls;
    $popup['site'] = $site;
    $popup['thread'] = $thread;
    $popup['htm'] = $htm;
    kv_set('aitu_baidutui', $popup);
    message(0, '提交成功！');
}
