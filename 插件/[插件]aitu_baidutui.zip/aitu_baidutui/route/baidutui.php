<?php

!defined('DEBUG') AND exit('Access Denied.');
	$config = kv_get('aitu_baidutui');
    	$url = $config['url'];
    	$urls = $config['urls'];
    	$api = $config['site'];
		$thread = $config['thread'];
		$htm = $config['htm'];
	$starts = mktime(0,0,0,date('m'),date('d'),date('Y'));
	$ends = time();
	$arrlist = db_sql_find("SELECT * FROM `bbs_".$thread."` WHERE `create_date` >= '$starts'  AND `create_date` <= '$ends'");
		$urllist = array();
		foreach ($arrlist as $isf){
			$urllist[] = $url.$thread.'-'.$isf['tid'].'.'.$htm;
		}
		$apis = htmlspecialchars_decode($api);
		$ch = curl_init();
		$options =  array(
    CURLOPT_URL => $apis,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => implode("\n", $urllist),
    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
		);
	curl_setopt_array($ch, $options);
	$result = curl_exec($ch);
	echo $result;
	if($urls){
		$urllist = array();
		foreach ($arrlist as $isf){
			$urllist[] = $urls.$thread.'-'.$isf['tid'].'.'.$htm;
		}
		$apis = htmlspecialchars_decode($api);
		$ch = curl_init();
		$options =  array(
    CURLOPT_URL => $apis,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => implode("\n", $urllist),
    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
		);
	curl_setopt_array($ch, $options);
	$result = curl_exec($ch);
	echo $result;	
			
	}
?>