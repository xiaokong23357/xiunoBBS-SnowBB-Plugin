<?php

!defined('DEBUG') and exit('Forbidden');
if (function_exists("xn_nav_menu_slot_add")) {
  xn_nav_menu_slot_add('news_ticker', array(
    array(
      'lid' => 1,
      'icon' => 'icon-spinner',
      'name' => '欢迎使用“滚动公告栏”插件！',
      'desc' => '',
      'href' => '#',
      'order' => 0,
      'class' => '',
      'submenu' => '',
    ),
    array(
      'lid' => 2,
      'icon' => 'icon-spinner',
      'name' => '作者：Tillreetree；点击查看更多精品插件！',
      'desc' => '',
      'href' => 'https://xiunobbs.cn/user-thread-1109.htm',
      'order' => 0,
      'class' => '',
      'submenu' => '',
    ),
    array(
      'lid' => 3,
      'icon' => 'icon-spinner',
      'name' => '请随意编辑这些预定义的链接吧！祝你使用愉快！',
      'desc' => '',
      'href' => '#',
      'order' => 0,
      'class' => '',
      'submenu' => '',
    ),
  ));
} else {
  message(-1, ' 安装失败');
}
$setting = setting_get('till_news_ticker_setting');
if (empty($setting)) {
  $setting = array(
    'single_time' => 5,
    'color_theme' => 'primary'
  );

  setting_set('till_news_ticker_setting', $setting);
}