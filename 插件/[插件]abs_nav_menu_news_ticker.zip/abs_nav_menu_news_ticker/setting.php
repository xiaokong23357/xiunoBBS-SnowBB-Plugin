<?php

!defined('DEBUG') and exit('Access Denied.');
$setting = setting_get('till_news_ticker_setting');
$profile = json_decode(file_get_contents(APP_PATH . "plugin/abs_nav_menu_news_ticker/" . "conf.json"), true);

$bootstrap_default_colors = array(
	'primary' => '主题主色',
	'secondary' => '主题辅助色',
	'success' => '绿色（成功）',
	'info' => '青色（信息）',
	'warning' => '橙色（警告）',
	'danger' => '红色（危险）',
	'light' => '亮色',
	'dark' => '暗色',
);

if ($method == 'GET') {

	$input = array();
	$input['single_time'] = form_text('single_time', $setting['single_time']);
	$input['color_theme'] = form_select('color_theme', $bootstrap_default_colors, $setting['color_theme']);

	include _include(APP_PATH . 'plugin/abs_nav_menu_news_ticker/setting.htm');
} else {

	$setting['single_time'] = max(intval(param('single_time', 1)), 1); //只能输入数字，且大于1
	$setting['color_theme'] = param('color_theme', '', true);

	setting_set('till_news_ticker_setting', $setting);
	message(0, '修改成功');
}