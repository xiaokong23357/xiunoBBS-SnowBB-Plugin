<?php

!defined('DEBUG') and exit('Forbidden');

$setting = setting_get('abs_shortcode_insert_setting');
if (empty($setting)) {
	$setting = array(
		'show_on_thread_create' => true, //在发帖/编辑帖子/高级回帖页面显示？
		'show_on_quickpost' => true, //在快速回帖框附近显示？
		'editor_thread_create' => 'tinymce_5', //发帖/编辑帖子/高级回帖页面 使用的编辑器
		'editor_quickpost' => 'vanilla', //快速回帖框 使用的编辑器
	);
	setting_set('abs_shortcode_insert_setting', $setting);
}