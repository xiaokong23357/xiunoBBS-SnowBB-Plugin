<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件设置
	admin/plugin-setting-abs_shortcode_insert.htm
*/

!defined('DEBUG') and exit('Access Denied.');

$setting = setting_get('abs_shortcode_insert_setting');

if ($method == 'GET') {

	$editor_choices = array(
		'vanilla' => '原版（未安装编辑器插件）',
		'umeditor' => 'UMEditor（对应-百度编辑器）',
		'tinymce_5' => 'TinyMCE 5（对应-大白TinyMCE 等）',
		'tinymce_6' => 'TinyMCE 6（对应-修罗中国TinyMCE 等）',
	);
	$input = array(
		'show_on_thread_create' => form_radio_yes_no('show_on_thread_create', $setting['show_on_thread_create']),
		'show_on_quickpost' => form_radio_yes_no('show_on_quickpost', $setting['show_on_quickpost']),
		'editor_thread_create' => form_radio('editor_thread_create', $editor_choices, $setting['editor']),
		'editor_quickpost' => form_radio('editor_quickpost', $editor_choices, $setting['editor']),
	);

	include _include(APP_PATH . 'plugin/abs_shortcode_insert/setting.htm');
} else {

	$setting = array(
		'show_on_thread_create' => param('show_on_thread_create', ''),
		'show_on_quickpost' => param('show_on_quickpost', ''),
		'editor_thread_create' => param('editor_thread_create', ''),
		'editor_quickpost' => param('editor_quickpost', ''),
	);
	$setting['body_start'] = param('body_start', '', FALSE);
	$setting['body_end'] = param('body_end', '', FALSE);
	$setting['footer_end'] = param('footer_end', '', FALSE);

	setting_set('abs_shortcode_insert_setting', $setting);

	message(0, '修改成功');
}