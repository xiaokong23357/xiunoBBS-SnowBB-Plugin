<?php

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('abs_shortcode_insert_setting');