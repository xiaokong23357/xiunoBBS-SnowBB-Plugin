let NewDate = new Date(),
    Year = NewDate.getFullYear(),
    hh = NewDate.getHours(),
    mm = NewDate.getMinutes(),
    hhmmt = hh + '.' + mm,
    dd = NewDate.getDay(),
    md = NewDate.getDate(),
    months = new Date(NewDate.getFullYear(), NewDate.getMonth() + 1, 0).getDate(),
    yy = NewDate.getMonth(),
    d1 = "2023/01/22 00:00:00",
    dateBegin = new Date(d1),
    dateDiff = NewDate.getTime() - dateBegin.getTime(),
    dayDiff = Math.floor(dateDiff / (24 * 3600 * 1000)),
    leave1 = dateDiff % (24 * 3600 * 1000),
    hours = Math.floor(leave1 / (3600 * 1000)),
    dayDifft = 365 + dayDiff,
    allreviews = document.querySelectorAll('.review');
if (dd == 0) {
    dd = 7
}
let reviewsTexts = [{
        title: '今天已过去 ' + hh + ' 小时',
        data_done: parseInt(hhmmt / 24 * 100)
    },
    {
        title: '本周已过去 ' + dd + ' 天',
        data_done: parseInt(dd / 7 * 100)
    },
    {
        title: '本月已过去 ' + md + ' 天',
        data_done: parseInt(md / months * 100)
    },
    {
        title: '今年已过去 ' + yy + ' 个月 零 ' + md + ' 天',
        data_done: parseInt(yy / 12 * 100)
    },
    {
        title: '距' + (Year + 1) + '年春节还剩 ' + Math.abs(dayDiff) + ' 天 ' + Math.abs(hours) + ' 小时',
        data_done: parseInt(dayDifft / 365 * 100)
    }
];
for (var i = 0; i < allreviews.length; i++) {
    allreviews[i].querySelector(".icon-container").innerText = reviewsTexts[i].title;
    allreviews[i].querySelector(".progress-done").style.width = reviewsTexts[i].data_done + '%';
    allreviews[i].querySelector(".percent").innerText = reviewsTexts[i].data_done + '%';

    let _progress_done = allreviews[i].querySelector(".progress-done");
    let _data_done = reviewsTexts[i].data_done;
    _data_done <= 100 && _data_done > 80 && (_progress_done_style('#d9534f'));
    _data_done <= 80 && _data_done > 60 && (_progress_done_style('#f0ad4e'));
    _data_done <= 60 && _data_done > 40 && (_progress_done_style('#5bc0de'));
    _data_done <= 40 && _data_done >= 0 && (_progress_done_style('#5cb85c'));

    function _progress_done_style(colors) {
        _progress_done.style.backgroundColor = colors;
        _progress_done.style.boxShadow = colors + " 0px 2px 5px 0px";
    }
}