	'medal'=>'蚀刻',
    'my_medal'=>'我的蚀刻',
    'medal_check'=>'蚀刻审核',