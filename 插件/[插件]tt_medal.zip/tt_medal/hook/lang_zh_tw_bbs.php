'medal'=>'蝕刻',
'my_medal'=>'我的蝕刻',
'medal_check'=>'蝕刻審核',