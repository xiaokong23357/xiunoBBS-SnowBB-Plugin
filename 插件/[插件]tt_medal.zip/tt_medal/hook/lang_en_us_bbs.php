'medal'=>'Medal',
'my_medal'=>'My Medal',
'medal_check'=>'Medal Check',