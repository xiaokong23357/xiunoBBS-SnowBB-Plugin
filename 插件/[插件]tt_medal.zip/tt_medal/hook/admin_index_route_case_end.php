case 'medal_user': include APP_PATH.'plugin/tt_medal/admin_user.php'; break;
case 'medal_check':include APP_PATH.'plugin/tt_medal/admin_check.php'; break;