<?php
!defined('DEBUG') AND exit('Access Denied.');
if($ajax) {
    $slot_name = param(1,'');
    if(empty($slot_name)) {
        message(1,'请提供栏位');
    }
    $menu_slot = xn_nav_menu_get($slot_name);
    message(0,$menu_slot);
} else {
    message(-1,'Bad Method');
}
