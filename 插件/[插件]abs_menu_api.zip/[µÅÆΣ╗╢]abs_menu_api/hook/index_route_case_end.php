case'nav_menu':
include _include(APP_PATH.'plugin/abs_menu_api/route/nav_menu.php');
break;