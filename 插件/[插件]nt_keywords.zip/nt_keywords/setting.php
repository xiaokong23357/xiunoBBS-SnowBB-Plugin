<?php

!defined('DEBUG') AND exit('Access Denied.');
if($method == 'GET') {
	$setting['nt_keywords'] = setting_get('nt_keywords');
	include _include(APP_PATH.'plugin/nt_keywords/setting.htm');
} else {

	setting_set('nt_keywords', param('nt_keywords', '', FALSE));
	setting_set('nt_keywords', param('nt_keywords', '', FALSE));
	message(0, '修改成功');
}
	
?>