<?php
!defined('DEBUG') and exit('Forbidden');
if (function_exists("xn_nav_menu_slot_del")) {
    xn_nav_menu_slot_del("slider_slot_1");
    xn_nav_menu_slot_del("slider_slot_2");
    xn_nav_menu_slot_del("slider_slot_3");
    xn_nav_menu_slot_del("slider_slot_4");
    xn_nav_menu_slot_del("slider_slot_5");
}