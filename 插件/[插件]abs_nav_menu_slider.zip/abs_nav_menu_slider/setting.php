<?php

!defined('DEBUG') and exit('Access Denied.');
$setting = setting_get('till_news_ticker_setting');
$profile = json_decode(file_get_contents(APP_PATH . "plugin/abs_nav_menu_slider/" . "conf.json"), true);

$setting = setting_get('abs_slider_setting');

if ($method == 'GET') {

	$input = array();
	$input['body_start'] = form_radio_yes_no('body_start', $setting['body_start']);
	$input['bs_version'] = form_radio('bs_version', array(4 => '4', 5 => '5'), $setting['bs_version']);

	include _include(APP_PATH . 'plugin/abs_nav_menu_slider/setting.htm');
} else {

	$setting['body_start'] = param('body_start', true);
	$setting['bs_version'] = param('bs_version', 4);

	setting_set('abs_slider_setting', $setting);

	message(0, '修改成功');
}