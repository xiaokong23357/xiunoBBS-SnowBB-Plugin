<?php
!defined('DEBUG') and exit('Forbidden');
if (function_exists("xn_nav_menu_slot_add")) {
    xn_nav_menu_slot_add('slider_slot_1', array(
        array(
            'lid' => 1,
            'icon' => 'icon-thumbs-o-up',
            'name' => '欢迎使用轮播图插件!',
            'desc' => '作者:Tillreetree',
            'href' => '#',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/1.jpg',
            'order' => 0,
            'submenu' => '',
        ),
        array(
            'lid' => 2,
            'icon' => 'icon-bars',
            'name' => '请进入后台"菜单"页面编辑我!',
            'desc' => '在编辑之前请看本插件的设置，了解如何正确填写',
            'href' => '#',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/2.jpg',
            'order' => 0,
            'submenu' => '',
        ),
        array(
            'lid' => 2,
            'icon' => 'icon-hand-peace-o',
            'name' => '祝您使用愉快!',
            'desc' => '点击本图了解更多插件',
            'href' => 'https://xiunobbs.cn/user-thread-1109.htm',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/3.jpg',
            'order' => 0,
            'submenu' => '',
        )
    ));
    xn_nav_menu_slot_add('slider_slot_2', array(
        array(
            'lid' => 1,
            'icon' => 'icon-comments',
            'name' => '轮播图槽位2',
            'desc' => '请编辑我',
            'href' => '#',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/2.jpg',
            'order' => 0,
            'submenu' => '',
        )
    ));
    xn_nav_menu_slot_add('slider_slot_3', array(
        array(
            'lid' => 1,
            'icon' => 'icon-comments',
            'name' => '轮播图槽位3',
            'desc' => '请编辑我',
            'href' => '#',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/3.jpg',
            'order' => 0,
            'submenu' => '',
        )
    ));
    xn_nav_menu_slot_add('slider_slot_4', array(
        array(
            'lid' => 1,
            'icon' => 'icon-comments',
            'name' => '轮播图槽位4',
            'desc' => '请编辑我',
            'href' => '#',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/4.jpg',
            'order' => 0,
            'submenu' => '',
        )
    ));
    xn_nav_menu_slot_add('slider_slot_5', array(
        array(
            'lid' => 1,
            'icon' => 'icon-comments',
            'name' => '轮播图槽位5',
            'desc' => '请编辑我',
            'href' => '#',
            'attr' => 'plugin/abs_nav_menu_slider/view/img/5.jpg',
            'order' => 0,
            'submenu' => '',
        )
    ));
}

$setting = setting_get('abs_slider_setting');
if (empty($setting)) {
    $setting = array('body_start' => true, 'bs_version' => 4);
    setting_set('abs_slider_setting', $setting);
}