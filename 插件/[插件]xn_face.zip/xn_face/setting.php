<?php
!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	include _include(APP_PATH.'plugin/xn_login_byuid/setting.htm');
	
} else {
    $op=param('op');
    if($op=='0'){
        
    }
    if($op=='1'){
        
    }
}
	
?>