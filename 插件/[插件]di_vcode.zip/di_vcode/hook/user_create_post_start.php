include _include(APP_PATH . 'plugin/di_vcode/model/vcode.fun.php');
$kv = kv_get('di_vcode_conf_data');
if($kv['creat_user'] !='0'){
$token= param('vaptcha_token');
if(empty($token))  message(1,"请先进行手势验证");	

$scene= '01';
$msg=validate_data($kv['vid'],$kv['key'],$scene,$token);

if(!$msg['success']){
	$err=$msg['msg'];
	if($err=='token-error')  $text='token错误,请检查vid和key是否正确';
	if($err=='token-expired')  $text='验证码已经过期，请刷新重试';
	if($err=='scene-error')  $text='场景号不存在';
	if($err=='over-user-limit')  $text='超过VIP用户自定义的频率上限';
	if($err=='id-error')  $text='vid错误';
	if($err=='id-empty')  $text='vid为空';
	if($err=='bad-request')  $text='请求错误';
	message(1,'错误信息：'.$text);	
}  	
	
}
 