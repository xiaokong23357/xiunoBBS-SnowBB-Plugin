<?php

/*
	插件安装文件
	初始化
*/

!defined('DEBUG') AND exit('Forbidden');
$conf_data=kv_get('di_vcode_conf_data');
if(empty($conf_data)){
	$conf_data=array(
	'vid'=>'你的vid',
	'key'=>'你的key',
	'type'=>'embed',
	'creat_user'=>"embed",
	'login_user'=>"embed",
	'creat_thread'=>"embed",
	'post_thread'=>"embed");
	
	kv_set('di_vcode_conf_data',$conf_data);
}

?>