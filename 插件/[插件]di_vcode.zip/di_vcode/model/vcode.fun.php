<?php
function  validate_data($vid,$key, $scene,$token){
	$ip= $_SERVER["REMOTE_ADDR"];
	$url='http://api.vaptcha.com/v2/validate';
	$data=['id'=>$vid,'secretkey'=>$key,'scene'=>$scene,'token'=>$token,'ip'=>$ip];
	$msg=http_post_data($url, $data);
	$data=json_decode($msg,1);
	return $data;
	
}




function http_post_data($url, $data) {
    $curl = curl_init(); //初始化
    curl_setopt($curl, CURLOPT_URL, $url); //设置抓取的url
    curl_setopt($curl, CURLOPT_HEADER, 0); //设置为0不返回请求头信息
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); //设置获取的信息以文件流的形式返回，而不是直接输出。
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); // 跳过https请求 不验证证书和hosts
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl, CURLOPT_POST, 1); //设置post方式提交
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data); //设置post数据，
    $data = curl_exec($curl); //执行命令
    curl_close($curl); //关闭URL请求
    return $data; //返回获得的数据
    
}