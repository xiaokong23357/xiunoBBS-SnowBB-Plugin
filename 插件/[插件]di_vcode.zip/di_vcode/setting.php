<?php

/*
	插件配置文件 (无配置则不需要此文件)
*/

!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	
	
	$kv = kv_get('di_vcode_conf_data');
	$input['vid'] = form_text('vid', $kv['vid']);
	$input['key'] = form_text('key', $kv['key']);
	$input['creat_user'] = form_select('creat_user', array('0'=>'关闭','embed'=>'镶入验证','click'=>'点击验证'),$kv['creat_user']);
	$input['login_user'] = form_select('login_user', array('0'=>'关闭','embed'=>'镶入验证','click'=>'点击验证'),$kv['login_user']);
	$input['creat_thread'] = form_select('creat_thread', array('0'=>'关闭','embed'=>'镶入验证','click'=>'点击验证'),$kv['creat_thread']);
	$input['post_thread'] = form_select('post_thread', array('0'=>'关闭','embed'=>'镶入验证','click'=>'点击验证'),$kv['post_thread']);

	
	include _include(APP_PATH.'plugin/di_vcode/setting.htm'); // 这里包含一个插件配置界面文件
	
} else {
	$kv = array();
	$kv['vid']=param('vid');
	$kv['key']=param('key');
	$kv['creat_user']=param('creat_user');
	$kv['login_user']=param('login_user');
	$kv['creat_thread']=param('creat_thread');
	$kv['post_thread']=param('post_thread');
	kv_set('di_vcode_conf_data', $kv);
     
	message(0, '修改成功');
}
	
?>