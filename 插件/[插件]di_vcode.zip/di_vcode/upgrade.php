<?php
/*
	插件升级文件
*/
!defined('DEBUG') AND exit('Forbidden');
$kv=array();
$kv=kv_get('di_vcode_conf_data');
$conf_data=array(
	'vid'=>$kv['vid'],
	'key'=>$kv['key'],
	'type'=>'embed',
	'creat_user'=>"embed",
	'login_user'=>"embed",
	'creat_thread'=>"embed",
	'post_thread'=>"embed");
kv_set('di_vcode_conf_data',$conf_data);
?>