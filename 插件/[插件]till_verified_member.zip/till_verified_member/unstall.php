<?php

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('till_verified_member_setting');

?>