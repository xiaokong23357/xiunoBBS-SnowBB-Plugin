	'v_main_nav'=>'加V认证',
	'v_sub_nav'=>'认证中心',
	'my_vresult'=>'我的认证',
	'inquire'=>'查询',