<?php
!defined('DEBUG') and exit('Forbidden');

setting_delete('till_cursor_futuristic_show_original_cursor');