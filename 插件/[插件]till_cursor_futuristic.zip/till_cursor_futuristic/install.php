<?php
!defined('DEBUG') and exit('Forbidden');

if (empty(setting_get('till_cursor_futuristic_show_original_cursor'))) {
	setting_set('till_cursor_futuristic_show_original_cursor', 0);
}