<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件设置
	admin/plugin-setting-xn_ad.htm
*/

!defined('DEBUG') and exit('Access Denied.');

if ($method == 'GET') {

	$input = form_radio_yes_no('till_cursor_futuristic_show_original_cursor', setting_get('till_cursor_futuristic_show_original_cursor'));
	include _include(APP_PATH . 'plugin/till_cursor_futuristic/setting.htm');
} else {

	setting_set('till_cursor_futuristic_show_original_cursor', param('till_cursor_futuristic_show_original_cursor', false));

	message(0, '修改成功');
}