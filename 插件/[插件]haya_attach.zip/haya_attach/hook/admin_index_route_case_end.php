
case 'attach':	
	include _include(APP_PATH.'plugin/haya_attach/route/attach.php'); 
	break;