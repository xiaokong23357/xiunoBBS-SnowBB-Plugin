<?php
!defined('DEBUG') and exit('Forbidden');
if (function_exists("xn_nav_menu_slot_del")) {
    xn_nav_menu_slot_del("friendlink");
}