<?php

!defined('DEBUG') and exit('Forbidden');

setting_delete('abs_nav_menus');