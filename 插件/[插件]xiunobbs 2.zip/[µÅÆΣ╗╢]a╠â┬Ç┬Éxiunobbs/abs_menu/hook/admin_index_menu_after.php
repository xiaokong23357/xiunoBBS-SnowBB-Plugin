<?php exit;

$menus_menu = array(
	'menus' => array(
		'url' => url('plugin-setting-abs_menu'),
		'text' => lang('menu'),
		'icon' => 'icon-bars',
	)
);
$menu += $menus_menu;