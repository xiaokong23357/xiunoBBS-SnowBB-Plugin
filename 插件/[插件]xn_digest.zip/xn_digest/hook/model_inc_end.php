
	include _include(APP_PATH.'plugin/xn_digest/model/thread_digest.func.php');
