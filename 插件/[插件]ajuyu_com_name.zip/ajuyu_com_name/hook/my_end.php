/*
聚宇网络
www.ajuyu.com
*/
//添加个人中心路径
if($action == 'name') {
	if($method == 'GET') {
		include _include(APP_PATH.'plugin/ajuyu_com_name/view/htm/my_name.htm');
	} elseif($method == 'POST') {
		$username_new = param('username_new');
		//$user_golds = param('user_golds');
		empty($username_new) AND message(-1, '不可以为空');
		$username_new == $user['username'] AND message(-1,'不可以和原来的名字相同');
		$ra = db_find_one('user', array('username' => $username_new));
		$ra != FALSE AND message(-1, '该 ID 已被占用, 请换一个' );
		$kv = kv_cache_get('renamesetting');		//查询设置
	    $type = $kv['type'];		//查询设置类型credits=经验golds=金币rmbs=人民币
	    $count = $kv['count'];		//查询设置积分
		if($type == 'credits'){
			if($user['credits'] < $count){
			    message(-1, '余额不足！修改失败！' );
		    }
		}else if($type == 'golds'){
			if($user['golds'] < $count){
			    message(-1, '余额不足！修改失败！' );
		    }
		}else if($type == 'rmbs'){
			if($user['rmbs'] < $count){
			    message(-1, '余额不足！修改失败！' );
		    }
		}
		// 验证是否拥有需要消耗数量的积分
   	$rb = user_update($uid, array('username'=>$username_new));
		$rb === FALSE AND message(-1, '修改失败, 请重试..  如果依旧不可以, 请联系管理员 错误状态:updateFALSE');
		if($type == 'credits'){
			$user_credits = $user['credits'] - $count;
		    $rb = user_update($uid,array('credits' => $user_credits));
		    $rb === FALSE AND message(-1, '修改失败, 余额扣除失败！');
		    $user['credits'] = $user_credits;
		    $user['username'] = $username_new; // 使顶部已经获取的 ID 替换为新的, 防止用户再看到原来的 ID
		    message(0, '修改成功，消耗：'.$count.'余额');
		}else if($type == 'golds'){
			$user_golds = $user['golds'] - $count;
		    $rb = user_update($uid,array('golds' => $user_golds));
		    $rb === FALSE AND message(-1, '修改失败, 余额扣除失败！');
		    $user['golds'] = $user_golds;
		    $user['username'] = $username_new; // 使顶部已经获取的 ID 替换为新的, 防止用户再看到原来的 ID
		    message(0, '修改成功，消耗：'.$count.'余额');
		}else if($type == 'rmbs'){
			$user_rmbs = $user['rmbs'] - $count;
		    $rb = user_update($uid,array('rmbs' => $user_rmbs));
		    $rb === FALSE AND message(-1, '修改失败, 余额扣除失败！');
		    $user['rmbs'] = $user_rmbs;
		    $user['username'] = $username_new; // 使顶部已经获取的 ID 替换为新的, 防止用户再看到原来的 ID
		    message(0, '修改成功，消耗：'.($count/100.0).'余额');
		}
	}
}