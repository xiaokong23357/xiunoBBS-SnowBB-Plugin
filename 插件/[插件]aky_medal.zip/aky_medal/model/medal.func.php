<?php
// 获取勋章列表-管理后台
function medalListGet($page=1,$pagesize=5){
    try {
        $r= db_find('medal', array(), array('mid'=>-1), $page, $pagesize,'mid');
        $count = medalListCount('medal');
        $arr = [];
        foreach ($r as &$_r) array_push($arr,$_r);
        $rtn = array(
            'data'=>$arr,
            'count'=>$count,
            'returnScale'=> intval(setting_get('tt_medal')['proportion']),
            'saleScale'=> intval(setting_get('tt_medal')['medalSale']),
        );
        return $rtn;
    } catch (Exception $e) {
        return -1;
    }
}
// 获取申请列表-管理后台
function medalAllApplyList($page=1,$pagesize=5){
    try {
        $r= db_find('medal_check', array('result'=>0), array(), $page, $pagesize);
        $count = db_count('medal_check',array('result'=>0));
        $arr = [];
        foreach ($r as &$_r){
            $MedalInfo = readOneMedalInfo($_r['mid']);
            $user = user_read($_r['uid']);
            $_r['filename'] = $MedalInfo['filename'];
            $_r['name'] = $MedalInfo['name'];
            $_r['user_name'] = $user['username'];
            $_r['groupname'] = $user['groupname'];
            $_r['time'] = date("Y-m-d",$_r['time']);
            array_push($arr,$_r);
        }
        $rtn = array(
            'data'=>$arr,
            'count'=>$count
        );
        return $rtn;
    } catch (Exception $e) {
        return -1;
    }
}
// 获取勋章列表-前端页面
function medalListViewGet($page=1,$pagesize=20,$uid){
    try {
        $r= db_find('medal', array(), array('mid'=>-1), $page, $pagesize,'mid');
        $count = medalListCount();
        $arr = [];
        foreach ($r as &$_r){
            $_r['ishave'] = medalUserReadHave($_r['mid'],$uid);
            $_r['ischeck'] = medalUserReadCheck($_r['mid'],$uid);
            array_push($arr,$_r);
        }
        $rtn = array(
            'data'=>$arr,
            'count'=>$count
        );
        return $rtn;
    } catch (Exception $e) {
        return -1;
    }
}
// 获取我的勋章列表-前端页面
function medalListMyViewGet($page=1,$pagesize=20,$uid){
    try {
        $r= db_find('user_medal', array('uid'=>$uid), array(), $page, $pagesize);
        $count = medalMyListCount($uid);
        $arr = [];
        foreach ($r as &$_r){
            $MedalInfo = readOneMedalInfo($_r['mid']);
            $_r['filename'] = $MedalInfo['filename'];
            $_r['name'] = $MedalInfo['name'];
            $_r['description'] = $MedalInfo['description'];
            $_r['isbuy'] = $MedalInfo['isbuy'];
            $_r['time'] = date("Y-m-d",$_r['time']);
            $_r['validity'] = intval(($_r['validity'] - time()) / 86400);
            array_push($arr,$_r);
        }
        $rtn = array(
            'data'=>$arr,
            'count'=>$count
        );
        return $rtn;
    } catch (Exception $e) {
        return -1;
    }
}
// 获取勋章列表-展示
function myMedalListShow($uid){
    $r= db_find('user_medal', array('uid'=>$uid), array('mid'=>-1), 1, 50);
    $arr = [];
    foreach ($r as &$_r){
        $MedalInfo = readOneMedalInfo($_r['mid']);
        $_r['filename'] = $MedalInfo['filename'];
        $_r['name'] = $MedalInfo['name'];
        $_r['description'] = $MedalInfo['description'];
        array_push($arr,$_r);
    }
    return $arr;
}
// 获取当前申请的勋章
function medalListMyApplyGet($page=1,$pagesize=20,$uid){
    try {
        $r= db_find('medal_check', array('uid'=>$uid), array('time'=>-1), $page, $pagesize);
        $count = medalMyApplyCount($uid);
        $arr = [];
        foreach ($r as &$_r){
            $MedalInfo = readOneMedalInfo($_r['mid']);
            $_r['filename'] = $MedalInfo['filename'];
            $_r['name'] = $MedalInfo['name'];
            $_r['description'] = $MedalInfo['description'];
            $_r['time'] = date("Y-m-d",$_r['time']);
            array_push($arr,$_r);
        }
        $rtn = array(
            'data'=>$arr,
            'count'=>$count
        );
        return $rtn;
    } catch (Exception $e) {
        return -1;
    }
}
function readOneMedalInfo($mid){
    $r= db_find_one('medal', array('mid'=>$mid));
    return $r;
}
// 根据id 与 用户uid搜索
function medalUserReadHave($mid,$uid){
    // 表示已拥有,表示未拥有
    $r = db_count('user_medal',array('mid'=>$mid,'uid'=>$uid));
    if($r>0){ return true ; }
    else { return false ; }
}
// 根据id 与 用户uid搜索
function medalUserReadCheck($mid,$uid){
    // 表示正在申请中,表示没有申请
    $r = db_count('medal_check',array('mid'=>$mid,'uid'=>$uid,'result'=>0));
    if($r > 0) return true; 
    else return false ;
}
// 获取当前勋章的个数
function medalListCount(){
    $count = db_count('medal');
    return $count;
}
// 获取当前我的勋章的个数
function medalMyListCount($uid){
    $count = db_count('user_medal',array('uid'=>$uid));
    return $count;
}
// 获取当前我的申请的勋章的个数
function medalMyApplyCount($uid){
    $count = db_count('medal_check',array('uid'=>$uid));
    return $count;
}
// 购买勋章
function medalBuy($uid,$mid,$time){
    $r = db_find_one('medal',array('mid'=>$mid));
    if(!$r || $r['isbuy'] == 0) return -1;
    $user = user_read($uid);
    if(!$user) return -2;
    $medalSale = setting_get('tt_medal')['medalSale'] /10;
    $isbought = db_find_one('user_medal',array('mid'=>$mid,'uid'=>$uid));
    if($isbought ) return -3;
    $credits_type = get_credits_name_by_type($r['money_type']);
    if($user[$credits_type] > 0 & $user[$credits_type] > $r['money'] * $time){
        $validity = 86400 * $time + strtotime('today');//当前时间+有效期
        $money = ceil($r['money'] * $time * $medalSale);
        db_update('user',array('uid'=>$uid),array($credits_type.'-'=>$money));
        db_insert('user_medal',array('uid'=>$uid,'mid'=>$mid,'time'=>time(),'validity'=>$validity));
        return 1;
    }else return -4;
}
// 回收勋章
function delMyMedal($uid,$mid){
    $r = db_find_one('medal',array('mid'=>$mid));
	if(!$r) return -1;
	$user = user_read($uid);
	if(!$user) return -2;
	if($r['isbuy']==0) return -3;
	$rr =  db_find_one('user_medal',array('uid'=>$uid,'mid'=>$mid));
	if(!$r) return -4;
	$credits_type = get_credits_name_by_type($r['money_type']);
	$proportion = setting_get('tt_medal')['proportion'] /10;
	$credits_ceil=ceil($r['money'] * intval(($rr['validity'] - time()) / 86400) * $proportion);
	db_update('user',array('uid'=>$uid),array($credits_type.'+'=>$credits_ceil));
	db_delete('user_medal',array('uid'=>$uid,'mid'=>$mid));
	notice_send('1', $uid, '您的勋章'.$r['name'].'已被回收,以返还'.$credits_ceil.'到您的账户', 233); // 3:系统通知
	return 1;
}
// 用户申请勋章
function medalApply($uid,$mid,$reason,$rid){
	$r = db_find_one('medal',array('mid'=>$mid));
	if(!$r) return -1;
	$user = user_read($uid);
	if(!$user) return -2;
	db_insert('medal_check',array('uid'=>$uid,'mid'=>$mid,'time'=>time(),'reason'=>$reason));
    // 	else $medalRulesList = json_decode(file_get_contents(APP_PATH.'plugin/aky_medal/static/rules.json'));
	medalSend($uid,$r['name'],0);
	return 1;
}
// 新增删除修改勋章-后台
function medalAddEditDel($mid,$arr,$type){
    if($type == 'add'){
        db_insert('medal',$arr);
    }elseif($type == 'edit') {
        db_update('medal', array('mid' => $mid), $arr);
    }elseif($type == 'del'){
        db_delete('medal',array('mid'=>$mid));
        db_delete('user_medal',array('mid'=>$mid));
    }
}
function adminCheckApplyMedal($mcid,$type,$time){
    $s = db_find_one('medal_check',array('mcid'=>$mcid));
    if(!$s) return 0;
    $r = db_find_one('medal',array('mid'=>$s['mid']));
    if(!$r) return -1;
    if($type == 1){
        $user = user_read($s['uid']);
        if(!$user) return -2;
        $isbought = db_find_one('user_medal',array('mid'=>$s['mid'],'uid'=>$s['uid']));
        if($isbought) return -3;
        $validity = 86400 * $time + strtotime('today');//当前时间+有效期
        db_insert('user_medal',array('uid'=>$s['uid'],'mid'=>$s['mid'],'time'=>time(),'validity'=>$validity));
        // 如果通过就删除记录
        db_delete('medal_check',array('mcid'=>$mcid));
        medalSend($s['uid'],$r['name'],1);
        return 1;
    }elseif($type == 2){
        // 没有通过则保留记录
        db_update('medal_check',array('mcid'=>$mcid),array('result'=>1));
        medalSend($s['uid'],$r['name'],2);
        return 1;
    }
}
// 发送系统通知
function medalSend($uid,$name,$type){
    //1同意,2拒绝
    switch ($type) {
        case '0':
            notice_send($uid, '1', '用户UID:'.$uid.'申请了勋章('.$name.')请批准', 233);
            break;
        case '1':
            notice_send('1',$uid,'您申请的'.lang('medal').'('.$name.')已被管理员批准发放', 233);
            break;
        case '2':
            notice_send('1',$uid,'您申请的'.lang('medal').'('.$name.')已被管理员拒绝发放', 233);
            break;
    }
}
?>