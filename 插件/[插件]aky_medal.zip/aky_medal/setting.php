<?php
!defined('DEBUG') AND exit('Access Denied.');
$action = param(3);
if(empty($action)){
    if($method == 'GET'){
        include _include(APP_PATH.'plugin/aky_medal/setting.htm');
    }
    elseif($method=='POST'){
        $op = param('op');
        // 数据查询,主设置页面
        if($op == 'listMedal'){
            try {
                $pageValue = param('pageValue');
                $pageSize = param('pageSize');
                $medallist = medalListGet($pageValue,$pageSize);
                if($medallist !=-1)message(0, $medallist);
                else message(-1);
            } catch (Exception $e ) {
                message(-1);
            }
        }
        // 数据查询,审核页面
        elseif($op == 'applyMedal'){
            try {
                $pageValue = param('pageValue');
                $pageSize = param('pageSize');
                $medallist = medalAllApplyList($pageValue,$pageSize);
                if($medallist !=-1)message(0, $medallist);
                else message(-1);
            } catch (Exception $e) {
                message(-1);
            }
        }
        // 新增勋章or修改勋章
        elseif($op == 'addMedal' || $op == 'editMedal'){
            try {
                $mid = param('mid',0);
                $name = param('name');
                $filename = param('filename');
                $description = param('description');
                $isbuy = param('isbuy');
                $money = param('money');
                $money_type = param('money_type');
                $rule_id = param('rule_id');
                $arr = array(
                    'name'=>$name,
                    'filename'=>$filename,
                    'description'=>$description,
                    'isbuy'=>$isbuy,
                    'money'=>$money,
                    'money_type'=>$money_type,
                    'rule_id' =>$rule_id
                );
                if($op == 'addMedal'){
                    medalAddEditDel($mid,$arr,'add');
                }elseif($op == 'editMedal'){
                    medalAddEditDel($mid,$arr,'edit');
                }
                message(0, '保存成功');
            } catch (Exception $e) {
                message(1, '保存失败');
            }
        }
        // 删除勋章
        elseif($op == 'delMedal'){
            try {
                $mid = param('mid',0);
                medalAddEditDel($mid,array(),'del');
                message(0, '删除成功');
            } catch (Exception $e) {
                message(1, '删除失败');
            }
        }
        // 设置返还比例与全局折扣比例
        elseif($op == "returnMedal"){
            $proportion = param('proportion');
            $medalSale = param('medalSale');
            if($proportion>10) $proportion = 10 ;
            if($medalSale>10) $medalSale = 10 ;
            setting_set('tt_medal',array('proportion'=>$proportion,'medalSale'=>$medalSale));
            message(0,'保存成功');
        }
        // 管理员审核
        elseif($op == "adminCheckApply"){
            try {
                $mcid = param('mcid',0);
                $type = param('type',0);
                $r = adminCheckApplyMedal($mcid,$type,30);
                if($r == 1) message(0,'审批完成！');
                elseif($r == 0) message(-1,'审批记录不存在！');
                elseif($r == -1) message(-1,'勋章不存在！');
                elseif($r == -2) message(-1,'用户不存在！');
                elseif($r==-3) message(-1,'勋章已拥有！');
            } catch (Exception $e) {
                message(-1,$e);
            }
        }
    }
}
?>