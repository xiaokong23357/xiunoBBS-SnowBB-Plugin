// 防抖
function simpleDebounce(fn, delay = 100) {
  let timer = null
  return function() {
    let args = arguments
    if (timer) {
      clearTimeout(timer)
    }
    timer = setTimeout(() => {
      fn.apply(this, args)
    }, delay)
  }
}
// 解析url参数
function getQuery(variable){
  let query = window.location.search.substring(1);
  let ele = query.split("&");
  for (let i=0;i<ele.length;i++) {
    let pair = ele[i].split("=");
    if(pair[0] == variable){return pair[1];}
  }
  return(false);
}