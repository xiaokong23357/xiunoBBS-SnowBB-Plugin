<?php exit;
if($action=='medal')
    if($method=='GET') {
        $_uid = param(2, 0);
        empty($_uid) AND $_uid = $uid;
        $_user = user_read($_uid);
        empty($_user) AND message(-1, lang('user_not_exists'));
        $header['title'] = $_user['username'].lang('medal').'列表';
        $header['mobile_title'] = $_user['username'].lang('medal').'列表';
        include _include(APP_PATH . 'plugin/aky_medal/view/htm/user_medal.htm');
    }elseif($method=='POST'){
        $op = param('op');
        if($op == 'listMedal'){
            $_uid = param('uid');
            $pageValue = param('pageValue');
            $pageSize = param('pageSize');
            $medallist = medalListMyViewGet($pageValue,$pageSize,$_uid);
            if($medallist != -1) message(0, $medallist);
            else message(-1);
        }
    }
?>