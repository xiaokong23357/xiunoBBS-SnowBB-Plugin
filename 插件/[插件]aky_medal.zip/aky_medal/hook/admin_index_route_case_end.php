case 'medal_user': include APP_PATH.'plugin/aky_medal/admin_user.htm'; break;
case 'medal_check':include APP_PATH.'plugin/aky_medal/admin_check.htm'; break;
case 'medal_log':include APP_PATH.'plugin/aky_medal/admin_log.htm'; break;