<?php exit;
elseif($action == 'medalIndex') {
    if($method == 'GET')
        include _include(APP_PATH.'plugin/aky_medal/view/htm/medal_Index.htm');
    elseif($method=='POST'){
        $op = param('op');
        if($op == 'listMedal'){
            $pageValue = param('pageValue');
            $pageSize = param('pageSize');
            $medallist = medalListViewGet($pageValue,$pageSize,$uid);
            if($medallist != -1) message(0, $medallist);
            else message(-1);
        }elseif($op == 'buyMedal'){
            $mid = param('mid','-1');
            $time = param('time',0);
            if($mid=='-1' || $time == 0) message(-1,'传参失败！');
            else {
                $r = medalBuy($uid,$mid,$time);
                switch ($r) {
                    case 1: message(0, lang("medal").'购买成功！');break;
                    case -1: message(-1, lang("medal").'不存在或不可购买');break;
                    case -2: message(-1,'用户不存在！');break;
                    case -3: message(-1, '您已拥有该'.lang("medal"));break;
                    case -4: message(-1,'用户积分不足');break;
                }
            }
            
        }elseif($op == 'myListMedal'){
            $pageValue = param('pageValue');
            $pageSize = param('pageSize');
            $medallist = medalListMyViewGet($pageValue,$pageSize,$uid);
            if($medallist != -1) message(0, $medallist);
            else message(-1);
        }elseif($op == "myApplyMedal"){
            $pageValue = param('pageValue');
            $pageSize = param('pageSize');
            $medallist = medalListMyApplyGet($pageValue,$pageSize,$uid);
            if($medallist != -1) message(0, $medallist);
            else message(-1);
        }
        elseif($op == 'delMyMedal'){
            $mid = param('mid','-1');
            if($mid=='-1') message(-1,'传参失败！');
            else {
                $r = delMyMedal($uid,$mid);
                switch ($r) {
                    case 1: message(0, lang("medal").'回收成功！');break;
                    case -1: message(-1, lang("medal").'不存在');break;
                    case -2: message(-1,'用户不存在！');break;
                    case -3: message(-1, '非卖'.lang("medal").'不可回收');break;
                    case -4: message(-1,'用户积分不足');break;
                }
            }
        }elseif($op == 'applyMedal'){
            $mid = param('mid','-1');
            $rid = param('rule_id','-1');
            if($mid=='-1') message(-1,'传参失败！');
            else {
                $result = param('result','');
                $r = medalApply($uid,$mid,$result,$rid);
                if($r == 1) message(0,'申请成功！');
                elseif($r == -1) message(-1,'勋章不存在！');
                elseif($r == -2) message(-1,'用户不存在！');
            }
        }
    }
}
?>