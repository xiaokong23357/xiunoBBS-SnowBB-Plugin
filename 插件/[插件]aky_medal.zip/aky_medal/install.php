<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;
//用户蚀刻表
$sql="CREATE TABLE IF NOT EXISTS `{$tablepre}user_medal` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `mid` int(10) NOT NULL,
  `time` int(20) DEFAULT '0',
  PRIMARY KEY (log_id),
	KEY (log_id),
	UNIQUE KEY (log_id)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
db_exec($sql);
//蚀刻列表
$sql="CREATE TABLE IF NOT EXISTS `{$tablepre}medal` (
  `mid` int(10) NOT NULL AUTO_INCREMENT,
  `name` CHAR(50) NOT NULL,
  `filename` VARCHAR(300) NOT NULL,
  `description` VARCHAR(200) NOT NULL,
  `isbuy` int(5) NOT NULL DEFAULT '0',
  `money` int(20) DEFAULT '0',
  `money_type` int(5) DEFAULT '0',
  PRIMARY KEY (mid),
	KEY (mid),
	UNIQUE KEY (mid)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
db_exec($sql);
//蚀刻审核表
$sql="CREATE TABLE IF NOT EXISTS `{$tablepre}medal_check` (
  `mcid` int(10) NOT NULL AUTO_INCREMENT,
  `mid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `reason` VARCHAR(200) NOT NULL,
  `time` int(20) DEFAULT '0',
  `result` int(10) NOT NULL,
  PRIMARY KEY (mcid),
	KEY (mcid),
	UNIQUE KEY (mcid)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
db_exec($sql);
//如果蚀刻列表为空则默认10个初始蚀刻
$medal_count = db_count('medal');
$default_medal = json_decode(file_get_contents(APP_PATH.'plugin/aky_medal/static/data.json'));
if($medal_count == 0)
    for($i=0;$i<=count($default_medal);$i++)
        db_insert('medal',array('name'=>'勋章'.($i+1),'filename'=>$default_medal[$i],'description'=>'我是勋章'.($i+1),'isbuy'=>0,'money'=>1,'money_type'=>1));
//20210319 新增了 销毁比例
//20210319 ADD proportion
//20211006 新增了折扣比例
$kv = array('proportion'=>5,'medalSale'=>10);
//tt_medal
setting_set('tt_medal',$kv);
//20210320 新增了有效期字段
$sql="ALTER TABLE `{$tablepre}user_medal` ADD COLUMN `validity` int(20) NULL DEFAULT 0 COMMENT '有效期';";
db_exec($sql);
?>