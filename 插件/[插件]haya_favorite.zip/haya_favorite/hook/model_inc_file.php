<?php
exit;

APP_PATH.'plugin/haya_favorite/model/haya_favorite.func.php',


?>