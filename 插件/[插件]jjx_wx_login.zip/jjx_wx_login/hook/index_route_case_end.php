
		case 'wx_login':		include _include(APP_PATH.'plugin/jjx_wx_login/route/wx_login.php'); 	break;