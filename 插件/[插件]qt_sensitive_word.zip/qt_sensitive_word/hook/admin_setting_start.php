<?php exit;
$menu['setting']['tab']['sensitive_word'] = array(
'url'=>url('setting-sensitive_word'),
'text'=>lang('sensitive_word_setting'),
);

