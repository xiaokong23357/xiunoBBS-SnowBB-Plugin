<?php

/*
	Xiuno BBS 4.0 插件：敏感词过滤设置
	admin/plugin-setting-qt_sensitive_word.htm
*/
!defined('DEBUG') AND exit('Access Denied.');

http_location('setting-sensitive_word.htm');