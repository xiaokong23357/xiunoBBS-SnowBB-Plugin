<?php

/*
	卸载
*/

!defined('DEBUG') AND exit('Forbidden');

?>