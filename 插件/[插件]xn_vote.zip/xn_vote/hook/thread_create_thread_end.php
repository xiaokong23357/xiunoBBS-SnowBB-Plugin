<?php exit;

// 对 id 进行处理
if($is_vote==1) {
	$create_time = $time;//创建时间
	$finish_time = $create_time+$vote_days*86400;//结束时间
		$arr = array(
			'tid'=>$tid,
			'uid'=>$uid,
			'create_time'=>$create_time,
			'finish_time'=>$finish_time,
			'type'=> $vote_type,
			'max'=>$vote_max,
			'subject'=>$vote_subject,
	); //投票主题信息
		$r = xn_vote_create($arr);//创建抽奖帖
		$xn_vote = db_find_one('xn_vote',array('tid'=>$tid));
		$vote_id = $xn_vote['vote_id'];
		foreach($vote_content_arr as $v) {
			$arr_optoin = array(
				'vote_id' => $vote_id,
				'tid' => $tid,
				'content' => $v,
			);
			xn_vote_info_create($arr_optoin);
		} //创建投票选项
	thread_update($tid, array('is_vote'=>1));//修改帖子状态为投票帖
}

?>