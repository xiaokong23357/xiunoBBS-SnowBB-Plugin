<?php
exit;
elseif ($action == 'post_vote') {
	$header['title'] = "投票接口" . $conf['sitename'];
	if ($method == 'POST') {
		$tid = param(2,0);
		if ($tid == 0){
			message(0, '参数缺失，请联系管理人员');	
		}
		$vote_info = vote_read($tid);
		if (empty($vote_info)){
			message(0, '投票帖不存在');	
		}
		$vote_id = $vote_info['vote_id'];
		$vote_check = xn_vote_check($uid,$tid);
		!empty($vote_check) AND message(0, '您已参与投票！');
		$nowtime=time();
		if ($nowtime>$vote_info['finish_time']){
			message(0, '投票已结束');	
		}
		$vote_message=_POST('vote_message');
        $vote_nums = count($vote_message);
        if ($vote_nums>$vote_info['max']){
            	message(0, '您的选项超过最大限制！');	
        }
		foreach($vote_message as $v){
		    $v_abs = intval($v);
			$r = db_find_one('xn_vote_detail', array('oid'=>$v_abs,'uid'=>$uid));
			$r2 = db_find_one('xn_vote_info', array('oid'=>$v_abs,'tid'=>$tid));
			if (empty($r) && !empty($r2)){
				$arr = array(
					'tid'=>$tid,
					'vote_id'=>$vote_id,
					'uid'=>$uid,
					'oid'=>$v_abs,
					'vote_time'=>$nowtime,
				);
				xn_vote_action($arr);
		}		
	}	

		message(1, '投票成功');
	} else{
		message(0, '非法访问');	
	}
}

?>