	
	if($isfirst && $thread['is_vote']==1) {
		xn_vote_delete($tid);
	} 