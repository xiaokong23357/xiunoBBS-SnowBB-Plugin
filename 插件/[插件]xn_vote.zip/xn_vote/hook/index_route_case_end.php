case'vote_piechart':
include _include(APP_PATH.'plugin/xn_vote/route/piechart.php');
break;