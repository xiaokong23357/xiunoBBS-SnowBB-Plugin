<?php exit;

// 对 id 进行处理
$is_vote = param('is_vote', 0);
if($is_vote==1) {
	$vote_subject = param('vote_subject');//投票主题
	$vote_type = param('vote_type', 0);//投票类型
	$vote_days = param('vote_days', 0);//投票天数
	$vote_max = param('vote_max', 0);//最大选择数
	$vote_content = param('vote_content');//投票选项内容
	if(
		empty($vote_subject)
		|| empty($vote_type   )
		|| empty($vote_days   )
		|| empty($vote_max    )
		|| empty($vote_content)
		){
		message(-1, '投票信息不完整');
	}
	$vote_days = intval($vote_days);
	$vote_max = intval($vote_max);
	$vote_type = intval($vote_type);
	if($vote_days<=0 || $vote_type<=0 ||  $vote_max<=0){
		message(-1, '投票信息错误');
	}
	$vote_content_arr = explode(", ",$vote_content); //将字符串转为数组
	foreach ($vote_content_arr as $k => $v){
	    $vote_content_arr[$k] =  trim($v); //删除多余字符串
	}
	$vote_content_arr = array_filter($vote_content_arr); //过滤数组空值
	if($vote_type==1){
	    $vote_max=1;
	}
	if(count($vote_content_arr)<$vote_max){
	    	message(-1, '投票选项数量小于最大选项');
	}
}

?>