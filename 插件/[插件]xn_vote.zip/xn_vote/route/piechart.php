<?php
ob_end_clean();
$data = array(
    param(1,0),
    param(2,0),
    param(3,0),
    param(4,0),
    param(5,0),
    param(6,0),
    param(7,0),
    param(8,0),
    param(9,0),
    param(10,0)
);
foreach ($data as $key => $value) {
    if($value === 0) {
        unset($data[$key]);
    }
}
$piegraph_data = array();
require_once _include(APP_PATH.'plugin/xn_vote/route/createimage.php');