<?php

/*
	XIUNO学院
	
*/
!defined('DEBUG') AND exit('Access Denied.');
if($method == 'GET') {
	$setting['xn_keywords'] = setting_get('xn_keywords');
	include _include(APP_PATH.'plugin/xn_keywords/setting.htm');
} else {

	setting_set('xn_keywords', param('xn_keywords', '', FALSE));
	setting_set('xn_keywords', param('xn_keywords', '', FALSE));
	message(0, '修改成功');
}
	
?>