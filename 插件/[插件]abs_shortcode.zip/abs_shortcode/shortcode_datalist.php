<?php defined('DEBUG') or die('potato'); //not today

$shortcodes = array(
    //*
    'b' => array(
        'name' => '粗体',
        'desc' => '',
        'syntax' => '[b]{text}[/b]',
    ),
    'i' => array(
        'name' => '斜体',
        'desc' => '',
        'syntax' => '[i]{text}[/i]',
    ),
    'u' => array(
        'name' => '下划线',
        'desc' => '',
        'syntax' => '[u]{text}[/u]',
    ),
    's' => array(
        'name' => '删除线',
        'desc' => '',
        'syntax' => '[s]{text}[/s]',
    ),
    'size' => array(
        'name' => '字体大小',
        'desc' => '单位为像素(px)',
        'syntax' => '[size={number}]{text}[/size]',
    ),
    'color' => array(
        'name' => '字体颜色',
        'desc' => '输入十六进制颜色（如#66ccff）',
        'syntax' => '[color={color}]{text}[/color]',
    ),
    'center' => array(
        'name' => '居中对齐',
        'desc' => '',
        'syntax' => ' [center]{text}[/center]',
    ),
    'right' => array(
        'name' => '右对齐',
        'desc' => '',
        'syntax' => '[right]{text}[/right]',
    ),
    'blockquote' => array(
        'name' => '块引用',
        'desc' => '',
        'syntax' => '[blockquote]{text}[/blockquote]',
    ),
    'url' => array(
        'name' => '链接',
        'desc' => '',
        'syntax' => '[url]{url}[/url]',
    ),
    'url_text' => array(
        'name' => '链接（定义显示文字）',
        'desc' => '',
        'syntax' => '[url={url}]{text}[/url]',
    ),
    'img' => array(
        'name' => '图片',
        'desc' => '',
        'syntax' => '[img]{src}[/img]',
    ),
    'img_size' => array(
        'name' => '图片（定义大小）',
        'desc' => '',
        'syntax' => '[img width={number_big},height={number_big}]{src}[/img]',
    ),
    'ul' => array(
        'name' => '无序列表',
        'desc' => '',
        'syntax' => '[ul]{items}[/ul]',
    ),
    'ol' => array(
        'name' => '有序列表（阿拉伯数字）',
        'desc' => '',
        'syntax' => '[ol]{items}[/ol]',
    ),
    'ol_lower-roman' => array(
        'name' => '有序列表—小写罗马数字',
        'desc' => '',
        'syntax' => '[list=i]{items}[/list]',
    ),
    'ol_upper-roman' => array(
        'name' => '有序列表—大写罗马数字',
        'desc' => '',
        'syntax' => '[list=I]{items}[/list]',
    ),
    'ol_lower-alpha' => array(
        'name' => '有序列表—小写字母',
        'desc' => '',
        'syntax' => '[list=a]{items}[/list]',
    ),
    'ol_upper-alpha' => array(
        'name' => '有序列表—大写字母',
        'desc' => '',
        'syntax' => '[list=A]{items}[/list]',
    ),
    'ol_cjk-ideographic' => array(
        'name' => '有序列表—小写汉字数字',
        'desc' => '是汉字“一”，不是减号“-”，也不是破折号“—”',
        'syntax' => '[list=一]{items}[/list]',
    ),
    'li' => array(
        'name' => '列表项',
        'desc' => '',
        'syntax' => '[*]{text}',
    ),
    'code' => array(
        'name' => '行内代码',
        'desc' => '',
        'syntax' => '[code]{text_code}[/code]',
    ),
    'pre' => array(
        'name' => '代码块（预格式化）',
        'desc' => '',
        'syntax' => '[pre]{text_pre}[/pre]',
    ),
    'spoiler' => array(
        'name' => '折叠内容',
        'desc' => '',
        'syntax' => '[spoiler]{text}[/spoiler]',
    ),
    'spoiler_summary' => array(
        'name' => '折叠内容（定义显示文字）',
        'desc' => '',
        'syntax' => '[spoiler={text}]{text}[/spoiler]',
    ),
    //*/
    // hook shortcode_datalist_end.php
);
