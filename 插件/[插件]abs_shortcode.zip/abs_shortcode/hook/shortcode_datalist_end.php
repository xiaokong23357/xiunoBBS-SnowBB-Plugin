/*'youtube' => array(
'name' => '嵌入 YouTube 视频',
'desc' => '',
'syntax' => '[youtube]...[/youtube]',
'sample' => ''
),*/
'login' => array(
'name' => '登录可见内容',
'desc' => '',
'syntax' => '[login] {text} [/login]',
'sample' => '<div class="alert alert-warning">此处有隐藏内容，请您<a>登录</a>后查看。</div>'
),
'reply' => array(
'name' => '回复可见内容',
'desc' => '',
'syntax' => '[reply] {text} [/reply]',
'sample' => '<div class="alert alert-warning">此处有隐藏内容，请您<a>回复</a>后查看。</div>'
),