//<?php
    /*
    // [youtube]...[/youtube] => <iframe src="..."></iframe>
    $this->bbcode_table["/\[youtube\](.*?)\[\/youtube\]/s"] = function ($match) {
        $url = urldecode(rawurldecode($match[1]));
        return '<iframe width="560" height="315" src="//www.youtube.com/embed/' . $match[1] . '" frameborder="0" allowfullscreen></iframe>';
    };
    //*/

    // [login]...[/login] => 登录用户可见
    $this->bbcode_table["/\[login\](.*?)\[\/login\]/is"] = function ($match) {
        global $user;
        if ($user) {
            return '<div class="alert alert-success">' . $match[1] . '</div>';
        } else {
            return '<div class="alert alert-info">' . '此处有隐藏内容，请您<a href="' . url('user-login') . '" class="alert-link">登录</a>后查看。' . '</div>';
        }
    };
    // [reply]...[/reply] => 回复用户可见
    $this->bbcode_table["/\[reply\](.*?)\[\/reply\]/is"] = function ($match) {
        global $uid, $tid, $thread;
        $is_reply = db_find_one('post', array('uid' => $uid, 'tid' => $tid));
        if (isset($thread['firstpid'])) {
            if ($is_reply || $thread['uid'] === $uid) {
                return '<div class="alert alert-success">' . $match[1] . '</div>';
            } else {
                return '<div class="alert alert-warning">' . '本帖有隐藏内容，请您<a href="' . url('post-create-' . $tid) . '" style="font-weight:bold;">回复</a>后查看。' . '</div>';
            }
        } else {
            return '<div class="alert alert-secondary">' . $match[1] . '</div>';
        }
    };