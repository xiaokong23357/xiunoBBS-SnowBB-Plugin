<?php defined('DEBUG') or die('potato'); //not today

include_once _include(APP_PATH . 'plugin/abs_shortcode/shortcode_datalist.php');

/**
 * BBCode库，来自[Flatboard](https://flatboard.org)
 * 作者：Frédéric Kaplon 和其他贡献者
 * Xiuno BBS移植版作者：Tillreetree
 * LOOK BUT DON'T TOUCH MOTHERFUCKER THINK TWICE!
 * 
 * BBCode Library, from [Flatboard](https://flatboard.org)
 * Author: Frédéric Kaplon and contributors
 * All Flatboard code is released under the MIT license.
 * 
 * @example ： echo BBCode::toHTML('[url=http://www.google.com/ ]A link to google[/url]');  // \<a href="http://www.google.com/">A link to google</a>
 */
class BBCode {
	/**
	 * 可以使用的BBCode，用于toHTML函数
	 *
	 * @see . BBCode::toHTML()
	 * @var array $bbcode_table 键：BBcodde的正则表达式；值：回调函数
	 */
	protected $bbcode_table = array();
	/**
	 * 因为这是一个静态类，所以是受保护的构造函数。
	 * Protected constructor since this is a static class.
	 *
	 * @access protected
	 * @return void
	 */
	public function __construct() {

		/**
		 * 如何添加自己的短代码？
		 * 
		 * 以“粗体”的短代码 “/\[b\](.*?)\[\/b\]/is” 为例，
		 * - “/\[b\]” 匹配 “[b]”
		 * - “(.*?)” 匹配 “任意内容”
		 * - “\[\/b\]” 匹配 “[/b]”
		 * - “i” 表示 “大小写不敏感”
		 * - “s” 表示 “点号元字符匹配所有字符，包含换行符”
		 * 每一个“(.*?)”的内容都会变成$match数组里的一项，按照出现顺序排序，例如：
		 * - $match[1]对应第一个“(.*?)”,
		 * - $match[2]对应第二个“(.*?)”，
		 * 以此类推。
		 * 同一个短代码可以同时拥有“带参数”和“不带参数”的版本，但需要实现两次，详见“email”的短代码。
		 * 
		 * 如果需要在回调函数里使用其他来自Xiuno BBS或插件中的变量，请使用global关键字，如：
		 * global $conf;   //站点配置数组
		 * global $header; //Header信息数组
		 * global $user;   //当前用户数组
		 * global $uid;    //用户ID
		 * global $gid;    //用户组ID
		 * global $fid;    //板块ID
		 * global $tid;    //帖子ID
		 * global $pid;    //回复ID
		 * global $route;  //当前路由
		 */

		/* ==========【内置BBCode开始】========== */
		/* ===== 如果不需要BBCode，请删掉下一行的【一个】斜杠 ===== */
		//*
		// [b]...[/b] => <strong>...</strong>
		$this->bbcode_table["/\[b\](.*?)\[\/b\]/is"] = function ($match) {
			return '<strong>' . $match[1] . '</strong>';
		};

		// [i]...[/i] => <em>...</em>
		$this->bbcode_table["/\[i\](.*?)\[\/i\]/is"] = function ($match) {
			return '<em>' . $match[1] . "</em>";
		};

		// [code]...[/code] => <code>...</code>
		$this->bbcode_table["/\[code\](.*?)\[\/code\]/is"] = function ($match) {
			return '<code>' . str_replace('<br />', '', $match[1]) . '</code>';
		};

		// [pre]...[/pre] => <pre>...</pre>
		$this->bbcode_table["/\[pre\](.*?)\[\/pre\]/is"] = function ($match) {
			return '<pre>' . $match[1] . '</pre>';
		};

		// [blockquote]...[/blockquote] => <blockquote><p>...</p></blockquote>
		$this->bbcode_table["/\[blockquote\](.*?)\[\/blockquote\]/is"] = function ($match) {
			return '<blockquote class="blockquote"><p>' . $match[1] . '</p></blockquote>';
		};

		// [size=30]...[/size] => <span style="font-size:30px">...</span>
		$this->bbcode_table["/\[size=(\d+)\](.*?)\[\/size\]/is"] = function ($match) {
			return '<span style="font-size:' . $match[1] . 'px">' . $match[2] . '</span>';
		};

		// [s]...[/s] => <del>...</del>
		$this->bbcode_table["/\[s\](.*?)\[\/s\]/is"] = function ($match) {
			return "<del>$match[1]</del>";
		};

		// [u]...[/u] => <span style="text-decoration:underline;">...</span>
		$this->bbcode_table["/\[u\](.*?)\[\/u\]/is"] = function ($match) {
			return '<span style="text-decoration:underline">' . $match[1] . '</span>';
		};

		// [spoiler]...[/spoiler] => <details>...</details>
		$this->bbcode_table["/\[spoiler\](.*?)\[\/spoiler\]/is"] = function ($match) {
			return '<details>' . $match[1] . '</details>';
		};

		// [spoiler=show more]...[/spoiler] => <details><summary>show more</summary>...</details>
		$this->bbcode_table["/\[spoiler=(.*?)\](.*?)\[\/spoiler\]/is"] = function ($match) {
			return '<details><summary>' . $match[1] . '</summary>' . $match[2] . '</details>';
		};

		// [center]...[/center] => <div style="text-align:center">...</div>
		$this->bbcode_table["/\[center\](.*?)\[\/center\]/is"] = function ($match) {
			return '<div style="text-align:center">' . $match[1] . '</div>';
		};

		// [right]...[/right] => <div style="text-align:right">...</div>
		$this->bbcode_table["/\[right\](.*?)\[\/right\]/is"] = function ($match) {
			return '<div style="text-align:right">' . $match[1] . '</div>';
		};

		// [color=#abcdef]...[/color] => <span style="color:#abcdef">...</span>
		$this->bbcode_table["/\[color=([#a-z0-9]+)\](.*?)\[\/color\]/is"] = function ($match) {
			return '<span style="color:' . $match[1] . ';">' . $match[2] . '</span>';
		};

		// [email]someone@example.com[/email] => <a href="mailto:someone@example.com">someone@example.com</a>
		$this->bbcode_table["/\[email\](.*?)\[\/email\]/is"] = function ($match) {
			return "<a href=\"mailto:$match[1]\">$match[1]</a>";
		};

		// [email=someone@example.com]An e-mail link[/email] => <a href="someone@example.com">An e-mail link</a>
		$this->bbcode_table["/\[email=(.*?)\](.*?)\[\/email\]/is"] = function ($match) {
			return "<a href=\"mailto:$match[1]\">$match[2]</a>";
		};

		// [url]http://www.google.com/[/url] => <a href="http://www.google.com/">http://www.google.com/</a>
		$this->bbcode_table["/\[url\](.*?)\[\/url\]/is"] = function ($match) {
			return "<a href=\"$match[1]\">$match[1]</a>";
		};

		// [url=http://www.google.com/]A link to google[/url] => <a href="http://www.google.com/">A link to google</a>
		$this->bbcode_table["/\[url=(.*?)\](.*?)\[\/url\]/is"] = function ($match) {
			return "<a href=\"$match[1]\">$match[2]</a>";
		};

		// [img]http://example.com/couple.png[/img] => <img src="http://example.com/couple.png"/>
		$this->bbcode_table["/\[img\](.*?)\[\/img\]/is"] = function ($match) {
			$file_name = "";
			if (!empty($match[1])) {
				//获取截取字符串开始位置
				$start = strrpos($match[1], '/') + 1;
				//获取截取字符串中的结束位置
				$end = strrpos($match[1], '.') - (strrpos($match[1], '/') + 1);
				//截取文档名称
				$file_name = substr($match[1], $start, $end);
			}
			return '<img src="' . $match[1] . '" class="img-fluid" alt="' . $file_name . '">';
		};

		// [img width=150,height=120]http://example.com/couple.png[/img] => <img style="width:150px; height:120px" src="http://example.com/couple.png"/>
		$this->bbcode_table["/\[img width=(\d+),height=(\d+)\](.*?)\[\/img\]/is"] = function ($match) {
			$file_name = "";
			if (!empty($match[3])) {
				//获取截取字符串开始位置
				$start = strrpos($match[3], '/') + 1;
				//获取截取字符串中的结束位置
				$end = strrpos($match[3], '.') - (strrpos($match[1], '/') + 1);
				//截取文档名称
				$file_name = substr($match[3], $start, $end);
			}
			return '<img style="width:' . $match[1] . 'px;height:' . $match[2] . 'px" src="' . $match[3] . '" class="img-fluid" alt="' . $file_name . '">';
		};

		// [ul][*]...[/ul] => <ul><li>...</li></ul>
		$this->bbcode_table["/\[ul\](.*?)\[\/ul\]/is"] = function ($match) {
			$match[1] = preg_replace_callback("/\[\*\]([^\[\*\]]*)/is", function ($submatch) {
				return "<li>" . preg_replace("/[\n\r?]$/", "", $submatch[1]) . "</li>";
			}, $match[1]);

			return "<ul>" . preg_replace("/[\n\r?]/", "", $match[1]) . "</ul>";
		};

		// [ol][*]...[/ol] => <ol><li>...</li></ol>
		$this->bbcode_table["/\[ol\](.*?)\[\/ol\]/is"] = function ($match) {
			$match[1] = preg_replace_callback("/\[\*\]([^\[\*\]]*)/is", function ($submatch) {
				return "<li>" . preg_replace("/[\n\r?]$/", "", $submatch[1]) . "</li>";
			}, $match[1]);

			return "<ol>" . preg_replace("/[\n\r?]/", "", $match[1]) . "</ol>";
		};

		// [list][*]...[/list] => <ul><li>...</li></ul>
		$this->bbcode_table["/\[list\](.*?)\[\/list\]/is"] = function ($match) {
			$match[1] = preg_replace_callback("/\[\*\]([^\[\*\]]*)/is", function ($submatch) {
				return "<li>" . preg_replace("/[\n\r?]$/", "", $submatch[1]) . "</li>";
			}, $match[1]);

			return "<ul>" . preg_replace("/[\n\r?]/", "", $match[1]) . "</ul>";
		};

		// [list=1][*]...[/list] => <ol><li>...</li></ol> //阿拉伯数字
		// [list=a][*]...[/list] => <ol><li>...</li></ol> //小写字母
		// [list=A][*]...[/list] => <ol><li>...</li></ol> //大写字母
		// [list=i][*]...[/list] => <ol><li>...</li></ol> //小写罗马数字
		// [list=I][*]...[/list] => <ol><li>...</li></ol> //大写罗马数字
		// [list=一][*]...[/list] => <ol><li>...</li></ol> //小写汉字数字
		$this->bbcode_table["/\[list=(1|a|A|i|I|一)\](.*?)\[\/list\]/s"] = function ($match) {
			switch ($match[1]) {
				case 'a':
					$list_type = '<ol style="list-style-type:lower-alpha">';
					break;
				case 'A':
					$list_type = '<ol style="list-style-type:upper-alpha">';
					break;
				case 'i':
					$list_type = '<ol style="list-style-type:lower-roman">';
					break;
				case 'I':
					$list_type = '<ol style="list-style-type:upper-roman">';
					break;
				case '一':
					$list_type = '<ol style="list-style-type:cjk-ideographic">';
					break;
				default:
					$list_type = '<ol>';
					break;
			}

			$match[2] = preg_replace_callback("/\[\*\]([^\[\*\]]*)/is", function ($submatch) {
				return "<li>" . preg_replace("/[\n\r?]$/", "", $submatch[1]) . "</li>";
			}, $match[2]);

			return $list_type . preg_replace("/[\n\r?]/", "", $match[2]) . "</ol>";
		};

		// [video width=560,height=315]http://www.example.com/video.mp4 [/video] => <video width="560" height="315" src="http://www.example.com/video.mp4" controls></video>
		$this->bbcode_table["/\[video width=(\d+),height=(\d+)\](.*?)\[\/video\]/s"] = function ($match) {
			if (!isset($match[1]) || $match[1] === 0) {
				$match[1] = 480;
			}
			if (!isset($match[2]) || $match[2] === 0) {
				$match[2]  = 360;
			}
			return '<video width="' . $match[1] . '" height="' . $match[2] . '" src="$match[3]" controls><source src="' . $match[3] . '" type="video/mp4">Your browser does not support the video tag or the file format of this video.</video>';
		};

		// [audio]http://www.example.com/audio.wav [/audio] => <audio src="http://www.example.com/audio.wav"></audio>
		$this->bbcode_table["/\[audio\](.*?)\[\/audio\]/is"] = function ($match) {
			return '<audio src="' . $match[1] . '">Your browser does not support the audio tag or the file format of this audio.</audio>';
		};
		//*/
		/* ==========【内置BBCode结束】========== */

		/* ==========【扩展短代码开始】========== */
		// hook shortcode_case_end.php
		/* ==========【扩展短代码结束】========== */
	}

	/**
	 * 将BBCode转换成HTML
	 *
	 * @param string $str 含有BBCode的字符串
	 * @param bool $escapeHTML  将特殊字符转换为 HTML 实体
	 * @param bool $nr2br 换行转换成\<br>标签
	 * @return string 转换成HTML的字符串
	 */
	public function toHTML($str, $escapeHTML = false, $nr2br = false) {
		if (!$str) return '';
		//return $str;
		if ($escapeHTML) $str = htmlspecialchars($str);
		foreach ($this->bbcode_table as $key => $val) {
			$str = preg_replace_callback($key, $val, $str);
		}
		if ($nr2br) $str = preg_replace_callback("/\n\r?/", function ($match) {
			return "<br/>";
		}, $str);
		return $str;
	}
}