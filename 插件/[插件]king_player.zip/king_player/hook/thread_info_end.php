<?php exit;
preg_match("/\[kingvod\](.*?)\[\/kingvod\]/i",$first['message_fmt'],$vod_url);
$kingvod = strip_tags(array_value($vod_url,1));
preg_match("/\[kinghttp\](.*?)\[\/kinghttp\]/i",$first['message_fmt'],$http_url);
$kinghttp = strip_tags(array_value($http_url,1));
$first['message_fmt'] = preg_replace("@\[king(.*?)\](.*?)\[/king(.*?)\]@is", '', $first['message_fmt']);
$first['message_fmt'] = preg_replace("/<p><br\/><\/p>/", '', $first['message_fmt']);
$first['message_fmt'] = preg_replace("/<p><\/p>/", '', $first['message_fmt']);
?>
