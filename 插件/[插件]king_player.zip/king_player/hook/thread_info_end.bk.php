<?php exit;
preg_match("/\[kingvod](.*)\[\/kingvod\]/",$first['message_fmt'],$vod_url);
$fkingvod = strip_tags(array_value($vod_url,1));
preg_match("/\[kinghttp](.*)\[\/kinghttp\]/",$first['message_fmt'],$http_url);
$fkinghttp = strip_tags(array_value($http_url,1));
$first['message_fmt'] = preg_replace("@\[king(.*?)\](.*?)\[/king(.*?)\]@is", '', $first['message_fmt']);
?>