<?php
/*
  国王多功能视频播放器插件卸载文件
  国域：https://king.sn
*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$sql = "DELETE FROM {$tablepre}kv WHERE `k` = 'king_player'";
$r = db_exec($sql);
?>