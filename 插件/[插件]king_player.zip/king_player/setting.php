<?php
/*
  国王多功能视频播放器插件卸载文件
  国域：https://king.sn
*/

!defined('DEBUG') AND exit('Forbidden');

if ($method == 'GET') {
    $king_player_kv = kv_cache_get('king_player');
    $api_url = isset($king_player_kv['api_url']) ? $king_player_kv['api_url'] : 'https://vip.parwix.com:4433/player/?url=';
    $player = isset($king_player_kv['player']) ? $king_player_kv['player'] : '1';	
	$autoplay = isset($king_player_kv['autoplay']) ? $fking_player_kv['autoplay'] : '1';
    include _include(APP_PATH.'plugin/king_player/king/theme/king_player_setting_theme.php');
} else {
    $data = $_POST;
    $king_player_kv = array();
    $king_player_kv['api_url'] = $data['api_url'];
    $king_player_kv['player'] = $data['player'];
	$king_player_kv['autoplay'] = $data['autoplay'];
    kv_cache_set('king_player', $king_player_kv);
    message(0, '设置成功');
}
?>