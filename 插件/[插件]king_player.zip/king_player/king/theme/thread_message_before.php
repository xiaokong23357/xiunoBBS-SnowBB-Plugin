
<?php
!defined('DEBUG') AND exit('Access Denied.');
$king_player_kv = kv_cache_get('king_player');
$autoplay = !empty($king_player_kv['autoplay']) ? 'true' : 'false';
?>
<style>
@media screen and (max-width:768px){#player{min-height:440px;}#player .video{height:440px!important;}#player_iframe{min-height:440px;}}@media(max-width:576px){#player{min-height:200px;}#player .video{height:200px!important;}#player_iframe{min-height:200px;}}@media(min-width:992px){#player{min-height:440px;}#player .video{height:440px!important;}#player_iframe{min-height:440px;}#player .dplayer-video-wrap .dplayer-video-current{min-height:440px;}}
</style>

<?php if( !empty($kingvod) || !empty($kinghttp) ){?>
<div id="player">
<?php if($kingvod){?>
    <?php if( $king_player_kv['player'] == 0){?>
		<script src="plugin/king_player/king/ckplayer/ckplayer.js"></script>
        <div class="video mt-1 mb-1" style="width:100%;height:100%;"></div>
        
        <script type="text/javascript">
          var videoObject = {
            container:'.video',//“#”代表容器的ID，“.”或“”代表容器的class
            variable:'player',//该属性必需设置，值等于下面的new chplayer()的对象
            autoplay:<?php echo $autoplay;?>,//自动播放 true false
            video:"<?php echo $kingvod;?>"//视频地址
          };
          var player=new ckplayer(videoObject);
        </script>
        
    <?php }else{ ?>
        <link rel="stylesheet" href="plugin/king_player/king/dplayer/DPlayer.min.css">        
        <script src="plugin/king_player/king/dplayer/flv.min.js"></script>
        <script src="plugin/king_player/king/dplayer/hls.min.js"></script>
        <script src="plugin/king_player/king/dplayer/DPlayer.min.js"></script>
        <div id="dplayer" class="mt-1 mb-1" style="width:100%;height:100%;"></div>
        <script type="text/javascript">
		  const dp = new DPlayer({
			  container:document.getElementById('dplayer'),
			  //screenshot:false,//截屏 此项需要跨域
			  autoplay:<?php echo $autoplay;?>,//自动播放 true false
			  video: {
				  url: '<?php echo $kingvod;?>',
				  type: 'auto'
			  }
		  });
        </script>
        
    <?php }?>
<?php }?>
<?php if( !empty($kinghttp) ){?>
<iframe src="<?php echo $king_player_kv['api_url'].$kinghttp;?>" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no" id="player_iframe" allowfullscreen="true" style="width:100%;height:auto;"></iframe><?php }?>

</div>
<?php }?>