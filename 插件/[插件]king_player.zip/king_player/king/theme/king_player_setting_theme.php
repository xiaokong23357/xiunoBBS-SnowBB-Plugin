<?php 
!defined('DEBUG') AND exit('Access Denied.');
include _include(ADMIN_PATH.'view/htm/header.inc.htm');?>
<style>
.input-group-text{width:110px!important;}@media (max-width: 576px){#body > .container > .row.mb-3{ margin-bottom:0px!important;}}
</style>
<div class="row mb-3">

  <div class="col-md-8">
    <div class="btn-group">
      <a class="btn btn-secondary" href="<?php echo url("plugin");?>">本地插件</a>
      <a class="btn btn-secondary active" href="<?php echo url("plugin-setting-king_player");?>">插件设置</a>
      <a class="btn btn-secondary" href="https://king.sn" target="_blank">国王首页</a>
    </div>
  </div>

  <div class="col-lg-4 text-right hidden-sm">
    <div class="btn-group">
      <a class="btn btn-dark" href="<?php echo url("plugin-setting-king_player");?>"><i class="icon-refresh"></i></a>
      <a class="btn btn-dark" href="<?php echo url("plugin");?>"><i class="icon-times"></i></a>
    </div>
  </div>
</div>

<div class="row">
	<div class="col-lg-12 mx-auto">
		<div class="card">
			<div class="card-body">
				<form action="<?php echo url("plugin-setting-king_player");?>" method="post" id="form">
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">解析地址：</span>
                        </div>
                        <input type="text" name="api_url" id="api_url" placeholder="国王提示您：请输入第三方API解析接口" value="<?php echo $api_url;?>" class="form-control" />
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">播放器类型：</span>
                        </div>
                        <div class="custom-input custom-radio form-control">
                            <input type="radio" name="player" value="0" <?php if ($player == 0) echo 'checked="checked"';?> /> Ckplayer
                            <input type="radio" name="player" value="1" <?php if ($player == 1) echo 'checked="checked"';?> /> Dplayer
                        </div>
                    </div>                    
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">自动播放：</span>
                        </div>
                        <div class="custom-input custom-radio form-control">                            
                            <input type="radio" name="autoplay" value="1" <?php if ($autoplay == 1) echo 'checked="checked"';?> /> 是
                            <input type="radio" name="autoplay" value="0" <?php if ($autoplay == 0) echo 'checked="checked"';?> /> 否 &nbsp; 『仅适用于MP4/M3U8格式；第三方API解析接口播放视频则取决于第三方播放器的设置。』
                        </div>
                    </div>
					<div class="form-group row">
						<div class="col-sm-12">
							<button type="submit" class="btn btn-primary btn-block" id="submit" data-loading-text="<?php echo lang('submiting');?>..."><?php echo lang('confirm');?></button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php include _include(ADMIN_PATH.'view/htm/footer.inc.htm');?>
<script>
var jform = $("#form");
var jsubmit = $("#submit");
var referer = '<?php echo url("plugin-setting-king_player");?>';
jform.on('submit', function(){
	jform.reset();
	jsubmit.button('loading');
	var postdata = jform.serialize();
	$.xpost(jform.attr('action'), postdata, function(code, message) {
		if(code == 0) {
			$.alert(message);
			jsubmit.text(message).delay(1000).button('reset').location(referer);
		} else {
			$.alert('提交失败');
			jsubmit.button('reset');
		}
	});
	return false;
});
</script>