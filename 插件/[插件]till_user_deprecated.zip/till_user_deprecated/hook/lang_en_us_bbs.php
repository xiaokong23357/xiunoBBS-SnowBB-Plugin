"my_deprecate_nav_label" => 'Deactivate',
"my_deprecate_heading" => 'Once your account is deactivated, it cannot be restored, so please <strong>do not try it at will</strong>!',
"my_deprecate_p1_title" => 'What happens when your account is deactivated',
"my_deprecate_p1" => array(
'User name will be reset to %1$s and password will be changed randomly',
'Empty all personal information (including but not limited to user groups, signatures, credits, etc., but NOT including the number of threads and posts)',
'Unbundle third party social accounts and phone numbers (if any)',
'User status is set to be <q>deactivated</q> and logging in is banned'
),
"my_deprecate_p1_alt" => array(
'This user will be deleted completely but can register again with that username and email address',
),
"my_deprecate_p2_title" => 'Traces of existence',
"my_deprecate_p2" => array(
'It is impossible to completely delete user data because once the content is posted, the data is associated between users and it leaves a trace of existence on the Internet.',
'You can delete your own threads, posts, etc. before deactivating your account.'),
"my_deprecate_p3_title" => 'If you decide you want to deactivate your account, please enter your username below.',
"my_deprecate_p3_input_placeholder" => 'Your username',
"my_deprecate_p3_submit_label" => 'Deactivate this account',
"user_is_deprecated" => 'This user is deactivated',
"Please enter the correct username" => 'Please enter the correct username',
"This user is deactivated and the content is not visible" => 'This user is deactivated and the content is not visible',