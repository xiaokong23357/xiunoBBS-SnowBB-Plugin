include _include(APP_PATH.'plugin/tt_reward/model/tt_reward.func.php');
