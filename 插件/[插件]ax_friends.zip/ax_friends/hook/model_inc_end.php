
	include _include(APP_PATH.'plugin/ax_friends/model/friends.fun.php');

