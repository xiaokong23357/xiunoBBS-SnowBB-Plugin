case 'friends': include _include(APP_PATH.'plugin/ax_friends/route/friends.php'); break;

