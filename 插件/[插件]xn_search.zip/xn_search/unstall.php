<?php

/*
	Xiuno BBS 4.0 插件实例：搜索插件卸载
	admin/plugin-unstall-xn_search.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>