
		case 'search': include _include(APP_PATH.'plugin/xn_search/route/search.php'); break;