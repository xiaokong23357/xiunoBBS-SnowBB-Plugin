<?php
/* 【开始】配置 */
$stately_setting_img_url_prefix = '../plugin/abs_theme_stately/view/img/_admin/';
$data = array(
  'panels' => [
    'global' => [
      'title' => '全局',
      'sections' => [
        'icon' => [
          'title' => '标志',
          '_cols' => 2,
          'options' => [
            'logo' => [
              'label' => '网站标志（Logo）',
              'type' => 'text',
              'default' => $conf['logo_pc_url'],
              'description' => '输入图标的网址'
            ],
            'favicon' => [
              'label' => '浏览器图标（Favicon）',
              'type' => 'text',
              'default' => $conf['logo_mobile_url'],
              'description' => '输入图标的网址'
            ],
          ],
        ],
        'search' => [
          'title' => '搜索',
          'description' => '',
          'options' => [
            'placeholder' => [
              'label' => '搜索框提示语',
              'type' => 'text',
              'default' => '想找什么？'
            ],
          ],
        ],
      ],
    ],
    'ui' => [
      'title' => '外观',
      'sections' => [
        'global' => [
          'title' => '全局',
          'options' => [
            'navbar_style' => [
              'label' => '导航栏风格',
              'description' => '菜单栏位：<br><b>纵向（左侧）</b>：左侧使用主菜单，顶部右侧使用副菜单，顶部左侧使用副副菜单；<br><b>横向（顶部）</b>：左侧使用主菜单，右侧使用副菜单，移动端一定启用左侧菜单',
              'type' => 'radio-image',
              'default' => 'vertical',
              'choices' => [
                'vertical' => [
                  'label' => '纵向（左侧）',
                  'url' => $stately_setting_img_url_prefix . 'ui.global.navbar_style.vertical.png'
                ],
                'horizontal' => [
                  'label' => '横向（顶部）',
                  'url' => $stately_setting_img_url_prefix . 'ui.global.navbar_style.horizontal.png'
                ],
              ]
            ],

            'show_top_left_menu' => [
              'label' => '显示顶部左侧菜单？',
              'description' => '仅在上一项为“纵向（左侧）”时有效！',
              'type' => 'hidden',
              'default' => true,
            ],
            'navbar_logo_show' => [
              'label' => '导航栏标志显示',
              'type' => 'select',
              'default' => 'both',
              'choices' => [
                'logo' => '只有标志',
                'text' => '只有文字 *若未设计标志，请选此项*',
                'both' => '标志和文字 *建议使用方形标志*',
              ],
            ],
            'show_appbar' => [
              'label' => '显示App底部栏？',
              'description' => '只在移动端可见',
              'type' => 'toggle',
              'default' => false,
            ],

            'use_twemoji' => [
              'label' => '使用Twemoji',
              'description' => '美观、统一的表情符号，开启后将替换全站所有的Emoji。',
              'type' => 'hidden',
              'default' => true,
            ]
          ],
        ],
        'color' => [
          'title' => '颜色',
          'options' => [
            'mode' => [
              'label' => '默认颜色模式',
              'type' => 'hidden',
              'default' => 'light',
            ],
            'theme' => [
              'label' => '配色（主色调）',
              'type' => 'color',
              'default' => '#696cff',
            ],
          ],
        ],
      ],
    ],
    'ui_style' => [
      'title' => '外观—板式',
      'sections' => [
        'homepage' => [
          'title' => '主页',
          'description' => '深一点的为当前选中的项目，下同。',
          'options' => [
            'layout' => [
              'label' => '板式',
              'type' => 'hidden',
              'default' => 'classic_2col',
            ],
          ],
        ],
        'forum' => [
          'title' => '论坛',
          'options' => [
            'layout' => [
              'label' => '板式',
              'type' => 'hidden',
              'default' => 'classic_2col',
            ],
            'style_forum_info' => [
              'label' => '论坛信息风格',
              'type' => 'hidden',
              'default' => 'top_v1',
            ],
          ],
        ],
        'threadlist' => [
          'title' => '帖子列表',
          'options' => [
            'style_global' => [
              'label' => '帖子列表风格（全局）',
              'type' => 'hidden',
              'default' => 'sns_v1',
            ],
            'cols_count_global' => [
              'label' => '栏数（全局）',
              'description' => '一行有几个帖子？',
              'type' => 'hidden',
              'default' => 12,
            ],
          ],
        ],
        'thread' => [
          'title' => '帖子详情',
          'options' => [
            'style_global' => [
              'label' => '帖子详情风格（全局）',
              'type' => 'hidden',
              'default' => 'classic_v2',
            ],
          ],
        ],
        'postlist' => [
          'title' => '回帖列表',
          'options' => [],
        ],
        'user' => [
          'title' => '用户',
          'options' => [],
        ],
        'login' => [
          'title' => '登录',
          'description' => '建议设置成同一种',
          'options' => [
            'style' => [
              'label' => '样式',
              'type' => 'hidden',
              'default' => 'v1',
            ],
          ],
        ],
        'register' => [
          'title' => '注册',
          'description' => '建议设置成同一种',
          'options' => [
            'style' => [
              'label' => '样式',
              'type' => 'hidden',
              'default' => 'v1',
            ],
          ],
        ],
        'resetpw' => [
          'title' => '忘记密码',
          'description' => '建议设置成同一种',
          'options' => [
            'style' => [
              'label' => '样式',
              'type' => 'hidden',
              'default' => 'v1',
            ],
          ],
        ],
      ],
    ],
    'ui_tweek' => [
      'title' => '外观—板式微调',
      'sections' => [
        'homepage_stats' => [
          'title' => '主页-站点统计',
          'options' => [
            'enable' => [
              'label' => '显示站点统计？',
              'type' => 'hidden',
              'default' => true,
            ],
            'style' => [
              'label' => '站点统计风格',
              'type' => 'hidden',
              'default' => 'v3',
            ]
          ],
        ],
        'threadlist' => [
          'title' => '帖子列表-通用',
          '_cols' => '2',
          'options' => [
            'show_thread_excerpt' => [
              'label' => '显示帖子摘要？',
              'description' => '请注意，某些板式完全不显示摘要；可能会导致网站变慢；若帖子内含有收费内容，则不显示摘要',
              'type' => 'hidden',
              'default' => true,
            ],
            'thread_excerpt_length' => [
              'label' => '帖子摘要字数',
              'description' => '单位为字。字母、数字、汉字皆算一个字符。输入“-1”显示帖子全文。',
              'type' => 'hidden',
              'default' => 140,
            ],
            'show_thread_thumbnail' => [
              'label' => '显示帖子缩略图？',
              'description' => '请注意，某些板式完全不显示缩略图；可能会导致网站变慢',
              'type' => 'hidden',
              'default' => true,
            ],
          ],
        ],
        'thread' => [
          'title' => '帖子详情-通用',
          'options' => [
            'show_thread_content_on_non_first_page' => [
              'label' => '非第一页显示帖子内容？',
              'description' => '用户在帖子第二页及之后的页码时，是否显示帖子正文？是：显示帖子正文，可能增加页码篇幅；否：Xiuno BBS默认行为。',
              'type' => 'hidden',
              'default' => false,
            ],
            'use_code_highlight' => [
              'label' => '代码高亮',
              'description' => '若帖子里包含代码块(pre标签)，将会自动应用代码高亮效果。',
              'type' => 'hidden',
              'default' => true,
            ],
            'show_floor_number' => [
              'label' => '显示楼层数？',
              'type' => 'hidden',
              'default' => true,
            ],
          ],
        ],
      ],
    ],
    'custom_content' => [
      'title' => '自定义内容',
      'sections' => [
        'global' => [
          'title' => '全局',
          'options' => [
            'footer_left_content' => [
              'label' => '页脚左侧文字',
              'description' => '可使用HTML',
              'type' => 'hidden',
              'default' => '&copy; ' . date('Y ') . 'Designed by <a href=\'https://themeselection.com\' target=\'_blank\' class=\'footer-link\'>ThemeSelection</a>'
            ],
            'footer_right_content' => [
              'label' => '页脚右侧文字',
              'description' => '可使用HTML',
              'type' => 'textarea_html',
              'default' => '自豪地采用Xiuno BBS'
            ],
            'footer_right_performance_info' => [
              'label' => '页脚右侧性能信息显示方式',
              'description' => '完整性能信息解释:🛢️（油桶）：数据库查询次数，⏰（闹钟）：服务器处理时间丨客户端加载时间，🍰（蛋糕）：服务器内存使用；非管理员看到的还是加载时间。',
              'type' => 'hidden',
              'default' => 'full',
            ],
          ],
        ],
      ],
    ],
    'custom_code' => [
      'title' => '自定义代码',
      'sections' => [
        'css' => [
          'title' => 'CSS',
          'options' => [
            'header' => [
              'label' => '自定义CSS',
              'type' => 'textarea',
              'default' => ''
            ],
          ]
        ],
        'javascript' => [
          'title' => '',
          'options' => [
            'before_body' => [
              'label' => 'body之前',
              'description' => '需要包含script标签；',
              'type' => 'textarea_html',
              'default' => ''
            ],
            'after_body' => [
              'label' => 'body之后',
              'description' => '需要包含script标签；统计代码放在这里',
              'type' => 'textarea_html',
              'default' => ''
            ],
          ]
        ],
      ],
    ],
    'page' => [
      'title' => '自定义内容—页面',
      'sections' => [
        'user_login' => [
          'title' => '登录',
          'options' => [
            'title' => [
              'label' => '页面标题',
              'type' => 'hidden',
              'default' => '欢迎来到' . $conf['sitename'] . '！',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'hidden',
              'default' => '请登录您的账号，开始你的旅途'
            ],
            'goto_register_text' => [
              'label' => '转到登录文案',
              'description' => '变量：%s——注册链接',
              'type' => 'hidden',
              'default' => '没有帐号？%s'
            ]
          ],
        ],
        'user_register' => [
          'title' => '注册',
          'options' => [
            'title' => [
              'label' => '页面标题',
              'type' => 'hidden',
              'default' => '万里之行，始于足下',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'hidden',
              'default' => '注册一个账号，开始你的旅途'
            ],
            'goto_login_text' => [
              'label' => '转到登录文案',
              'description' => '同样适用于忘记密码页面。变量：%s——登录链接',
              'type' => 'hidden',
              'default' => '已有帐号？%s'
            ]
          ],
        ],
        'user_forgetpw' => [
          'title' => '忘记密码',
          'options' => [
            'title' => [
              'label' => '页面标题',
              'type' => 'hidden',
              'default' => '忘记密码',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'hidden',
              'default' => 'Forget Password'
            ],
            'goto_login_text' => [
              'label' => '转到登录文案',
              'description' => '同样适用于忘记密码页面。变量：%s——登录链接',
              'type' => 'hidden',
              'default' => '想起密码了？%s'
            ]
          ],
        ],
      ],
    ],
    'about' => [
      'title' => '关于',
      'sections' => [
        'about_theme' => [
          'title' => '关于 ' . $PLUGIN_PROFILE['name'],
          'options' => [
            'cp_notice' => [
              'label' => '<b>重要提示</b>',
              'type' => 'label',
              'default' => '<b>非官方来源主题</b>可能包含恶意代码，影响网站的安全性与速度。<br>本主题未进行加密，所以您可以查阅、学习、修改本主题的任何部分，不代表您可以在修改后再加密并二次转售。'
            ],
            'lite_notice' => [
              'label' => 'Lite版提示',
              'type' => 'label',
              'default' => '您目前在使用Lite版，若觉得本主题不错或需要更多功能，请考虑捐款支持作者来换取完整版。'
            ],
            'authors' => [
              'label' => '作者',
              'type' => 'label',
              'default' => '<a href="https://www.geticer.eu.org">Geticer</a>'
            ],
            'credits' => [
              'label' => '鸣谢',
              'type' => 'label',
              'default' => implode('<br>', [
                'ThemeSelection - 外观设计',
                'Tillreetree - 制作协力',
                'ZAESKY - 灵感提供、致敬',
                '七濑胡桃 - 精神支持',
              ])
            ],
            'thank_you_beta_testers' => [
              'label' => '感谢Beta测试者',
              'type' => 'label',
              'default' => implode('<br>', [
                '7232708273',
                'Moonun0930',
                'beyond0729',
                'fenge',
                'XIUNO学院',
                '委员长',
              ])
            ],
            'C0FFEE' => [
              'label' => $PLUGIN_PROFILE['nothing_to_see_here_move_along'][0],
              'description' => '你的支持是我<abbr title="字面意思">维护本主题的动力！</abbr>',
              'type' => 'label',
              'default' => '<img src="' . str_rot13($PLUGIN_PROFILE['nothing_to_see_here_move_along'][4] . ';' . $PLUGIN_PROFILE['nothing_to_see_here_move_along'][2]) . ',' . $PLUGIN_PROFILE['nothing_to_see_here_move_along'][1] . '" class="img-thumbnail img-fluid w-50 w-px-300 mx-auto" style="' . str_rot13($PLUGIN_PROFILE['nothing_to_see_here_move_along'][3]) . '" />'
            ]
          ],
        ],
      ],
    ],
  ],
  'kumquat_config' => [ /* 金桔框架——框架设置 */
    'allow_delete_plugin_settings' => true, /* 允许删除插件设置 */
    'allow_reset_settings' => false, /* 允许重置插件设置 */
    'show_all_vars_table' => false, /* 显示“全部变量”框，只在调试模式显示 */
  ],
  'kumquat_flag' => [ /* 金桔框架——FLAG；保存在插件设置中，除非有必要，否则勿动 */
    'delete_plugin_settings' => true, /* 删除插件设置，若为true则会在卸载时删除插件设置 */
    'reset_settings' => false, /* 重置插件设置，若为true则重置 */
  ],
);
/* 【结束】配置 */