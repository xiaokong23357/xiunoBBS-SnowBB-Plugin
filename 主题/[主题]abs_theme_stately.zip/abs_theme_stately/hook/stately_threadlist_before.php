//<?php
    /* Stately Threadlist init BEGIN */

    /**
     * @var string $stately_threadlist_style 帖子列表风格
     */
    $stately_threadlist_style = 'sns_v1';

    /**
     * @var int $stately_threadlist_cols_count 帖子列表列数
     */
    $stately_threadlist_cols_count = 12;

    /**
     * @var string $stately_threadlist_class_add 帖子列表衬底
     */
    $stately_threadlist_class_add = '';

/* Stately Threadlist init END */