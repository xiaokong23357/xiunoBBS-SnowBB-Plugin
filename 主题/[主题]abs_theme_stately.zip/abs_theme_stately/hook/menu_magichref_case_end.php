//<?php if (true) :
/* =====Stately主题【开始】===== */

/* =====文字分隔符（用于菜单）===== */
elseif ($menu_item['href'] === "__divider_text__") :

    if (!(isset($menu_item['submenu']) && !empty($menu_item['submenu'])) || $args['container_class'] != 'dropdown-menu') {
        $r .= '<li class="menu-header small">' . '<span class="menu-header-text">' . $menu_item['name'] . '</span>' . '</li>';
    } else {
        continue;
    }

/* =====用户菜单中的“用户头像、用户名、用户组”组合成一个菜单项===== */
elseif ($menu_item['href'] === "__user_brief__") :
    $abs_theme_stately_setting = setting_get('abs_theme_stately_setting');
    //*
    if ((isset($menu_item['submenu']) && !empty($menu_item['submenu'])) || stripos($args['menu_class'], 'dropdown-menu') !== false) {
        $r .= '<div class="dropdown-item">'
            . '<div class="d-flex">'
            . '<div class="flex-shrink-0 me-3 py-1">'
            . '<div class="avatar">'
            . '<a href="' . url('my') . '">'
            . '<img src="' . $user['avatar_url'] . '" alt="' . $user['username'] . '" class="w-px-40 h-auto rounded-circle">'
            . '</a>'
            . '</div>'
            . '</div>'
            . '<div class="flex-grow-1">';
            //*
        if (function_exists('vip__isvip') && vip__isvip($user['vip_end']) && function_exists('vip_read')) { //如果是VIP
            $vip_info = vip_read($uid);
            $r .= '<a href="' . url('my') . '" class="fw-semibold d-block text-danger isvip">' . $user['username'] . '</a>'
            . '<small class="fw-semibold d-block isvip"><span class="badge bg-label-warning">VIP Lv.' . $vip_info['level'] . '</span></small>';
            unset($vip_info);
        } else { //普通用户
            $r .= '<a href="' . url('my') . '" class="fw-semibold d-block">' . $user['username'] . '</a>';
        }
        //*/
        $r .= '<small class="badge bg-label-secondary">' . $user['groupname'] . '</small>';
        $r .= '</div>'
            . '</div>'
            . '</div>';

    } else {
        continue;
    } 
    //*/

/* =====用户头像（带二级菜单）===== */
elseif ($menu_item['href'] === "__user_avatar_submenu__") :

    if ($uid != 0) {
        $r .= '<li class="nav-item navbar-dropdown dropdown-user dropdown">'
            . '<a class="nav-link dropdown-toggle hide-arrow" data-bs-toggle="dropdown">'
            . '<div class="avatar">'
            . '<img src="' . $user['avatar_url'] . '" alt="' . $user['username'] . '" class="img-fluid rounded-circle">'
            . '</div>'
            . '</a>'
            . xn_nav_menu(array(
                'menu' => 'user_menu',
                'container' => false,
                'menu_class' => 'dropdown-menu dropdown-menu-end',
                'link_class' => 'dropdown-item',
                'echo' => false
            ))
            . '</li>';
    } else {
        continue;
    }

/* =====搜索弹窗===== */
elseif ($menu_item['href'] === "__stately_search_modal__") :
    $_this_item = array(
        'icon' => $menu_item['icon'],
        'name' => $menu_item['name'],
        'href' => '#statelySearchModal',
        'class' => $menu_item['class'],
            'before' => $args['menu'] === 'appbar_menu' ? '<span>' : '<span class="d-none d-md-inline">',
            'after' => '</span>',
        'attr' => 'data-bs-toggle="modal" data-bs-target="#statelySearchModal"'
    );
    $r .= xn_nav_menu_item($_this_item, $args);
/* =====通知弹窗===== */
elseif ($menu_item['href'] === "__stately_notice_modal__"):
    if ($uid != 0 && isset($user['unread_notices'])) {
        $_this_item = array(
            'icon' => $menu_item['icon'],
            'name' => $menu_item['name'],
            'href' => '#statelyNotificationModal',
            'before' => $args['menu'] === 'appbar_menu' ? '<span>' : '<span class="d-none d-md-inline">',
            'after' => ($user['unread_notices'] != 0 ? '</span> <b class="badge badge-danger">' . $user['unread_notices'] . '</b>' : '</span>'),
            'attr' => 'data-bs-toggle="offcanvas" data-bs-target="#statelyNotificationModal" aria-controls="statelyNotificationModal"'
        );
        $r .= xn_nav_menu_item($_this_item, $args);
    } else {
        continue;
    }
/* =====登录弹窗===== */
elseif ($menu_item['href'] === "__stately_login_modal__"):
    if ($uid == 0) {
        if ($args['menu'] === 'appbar_menu') {
                $_this_item = array(
                    'icon' => $menu_item['icon'],
                    'name' => '',
                    'href' => '#',
                    'link_class' => 'btn btn-primary' . $menu_item['class'],
                    'link_attr' => 'role="button"',
                    'attr' => 'data-bs-toggle="modal" data-bs-target="#statelyLoginModal"'
                );
        } else {
            $_this_item = array(
                'icon' => $menu_item['icon'],
                'name' => lang('login'),
                'href' => '#',
                'link_class' => 'btn btn-primary ' . $menu_item['class'],
                'link_attr' => 'role="button"',
                'attr' => 'data-bs-toggle="modal" data-bs-target="#statelyLoginModal"'
            );
        }
        
        $r .= xn_nav_menu_item($_this_item, $args);
    } else {
        $r .= '';
    }

/* =====Stately主题【结束】===== */

//endif;