<?php

/**
 * 显示目录模块
 *
 * @param string $content 要解析的内容
 * @param string $display_position 要显示的位置
 */
function article_toc($content, $display_position = '') {
    //var_dump($content);
    $index = '';
    $ol  = '';
    $arr = array();
    $pattern = '/<h([2-6]).*?\>(.*?)<\/h[2-6]>/is';
    $has_index = false;

    //*
    if (preg_match_all($pattern, $content, $arr)) {
        $has_index = true;
        $count = count($arr[0]);
        foreach ($arr[1] as $k => $v) {
            //添加列表头

            if ($k <= 0) {
                $index .= '<ol>'; //顶级
            } else {
                if ($v > $arr[1][$k - 1]) {
                    if ($v - $arr[1][$k - 1] == 1) {
                        $index .= '<li><ol>'; //上层小，层级高，当前为子层，先输出ol
                    } elseif ($v == $arr[1][$k - 1]) {
                    } else {
                        $index .= lang("article_toc_illegal");
                        return $content;
                    }
                }
            }
            $title   = strip_tags($arr[2][$k]);
            $content = str_replace($arr[0][$k], '<h' . $v . ' id="index-' . $k . '">' . $title . '</h' . $v . '>', $content);
            $index .= '<li class="toc-level' . $v . '"><a href="#index-' . $k . '">' . $title . '</a></li>'; //输出本层li
            //列表封闭规则
            if ($k < $count - 1) {
                if ($v > $arr[1][$k + 1]) { //当前层大于下一层，本层结束，封底
                    $c = $v - $arr[1][$k + 1];
                    for ($i = 0; $i < $c; $i++) {
                        $ol .= '</ol></li>';
                        $index .= $ol;
                        $ol = '';
                    }
                }
            } else {
                $index .= '</ol>';
            }
        }
    }
    //var_dump($display_position);
    $new_content = '';
    switch ($display_position) {
        case 'thread':
            if ($has_index) {
                $new_content = "<details id='table_of_contents__thread' class='border border-info accordion-item float-end'>"
                    . "<summary class='accordion-header accordion-button'>" . lang("article_toc_title") . "</summary>"
                    . "<section class='accordion-body'>"
                    . "<div class='table_of_contents'>"
                    . $index
                    . "</div>"
                    . "</section>"
                    . "</details>"
                    . $content;
            } else {
                $new_content = $content;
            }
            break;
        case 'thread_auto':
            if ($has_index) {
                $new_content = "<details id='table_of_contents__thread' class='border border-info accordion-item float-end d-block d-lg-none'>"
                    . "<summary class='accordion-header accordion-button'>" . lang("article_toc_title") . "</summary>"
                    . "<section class='accordion-body'>"
                    . "<div class='table_of_contents'>"
                    . $index
                    . "</div>"
                    . "</section>"
                    . "</details>"
                    . $content;
            } else {
                $new_content = $content;
            }
            break;
        case 'widget':
            if ($has_index) {
                $new_content = "<h4 class='h6 card-header'>" . lang("article_toc_title") . "</h4>"
                    . "<section class='card-body'>"
                    . "<div class='table_of_contents'>"
                    . $index
                    . "</div>"
                    . "</section>";
            } else {
                $new_content = "";
            }
            break;

        default:
            $new_content = "<details id=\"article-index\" class='table_of_contents'>"
                . "<summary>" . lang("article_toc_title") . "</summary>"
                . "<section id='table_of_contents'>\n" . $index . "</section>"
                . "</details>\n"
                . $content;
            break;
    }
    //*/
    return $new_content;
}
