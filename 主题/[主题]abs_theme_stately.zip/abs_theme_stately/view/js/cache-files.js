
const cacheName = 'my-app-v1.0.0'

const files = [
    '/',
]