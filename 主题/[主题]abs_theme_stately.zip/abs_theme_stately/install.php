<?php
!defined('DEBUG') and exit('501 Not Implemented');

/* 【开始】安装配置 */

/**
 * @var bool $REPLACE_MENU_ITEMS 在安装时替换主菜单、副菜单、副副菜单栏位内容？
 * true = 替换
 * false = 不替换
 * （如果你已经编辑好了菜单，请选择false）
 */
$REPLACE_MENU_ITEMS = true;

/* 【结束】安装配置 */



















/* 【开始】金桔框架——常量定义 */

$BASE_URL = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$BASE_URL = empty($BASE_URL) ? '/' : '/' . trim($BASE_URL, '/') . '/';

define('WEBSITE_DIR', $_SERVER["HTTP_HOST"] . $BASE_URL);
define('PLUGIN_DIR', 'plugin/' . param(2) . '/');
define('PLUGIN_NAME', param(2));
$plugin_profile_file = file_get_contents(APP_PATH . PLUGIN_DIR . 'conf.json');
$PLUGIN_PROFILE = json_decode($plugin_profile_file, true);
$PLUGIN_SETTING = setting_get(PLUGIN_NAME . '_setting');
include_once(APP_PATH . PLUGIN_DIR . 'conf.php');

/* 【结束】金桔框架——常量定义 */

/**
 * 金桔框架——初始化设置
 * @param array $data 要导入的设置数组。
 * @return array 每一个设置项
 */
function kumquat_setting_init($data) {
    $setting = array();
    if (!isset($data['panels'])) {
        return $setting;
    } else {
        foreach ($data['panels'] as $panel => $value) {
            #$controller_name_panel = $panel;
            foreach ($value['sections'] as $section => $value) {
                #$controller_name_section = $controller_name_panel.'/'.$section;
                foreach ($value['options'] as $option => $control) {
                    #$controller_name = $controller_name_section.'/'.$option;
                    if (isset($control['default'])) {
                        $setting[$panel][$section][$option] = $control['default'];
                    } else {
                        $setting[$panel][$section][$option] = 0;
                    }
                }
            }
        }
    }
    foreach ($data['kumquat_flag'] as $key => $value) {
        $setting['kumquat_flag'][$key] = $value;
    }
    return $setting;
}
//*
if (empty($PLUGIN_SETTING)) {
    $setting = kumquat_setting_init($data);
    setting_set(PLUGIN_NAME . '_setting', $setting);
}

if (function_exists("xn_nav_menu_slot_add")) {
    xn_nav_menu_slot_add('bbspage', array(
        array('lid' => 1, 'icon' => 'la la-comments', 'name' => '全部板块', 'desc' => '', 'href' => '__forumlist_section__', 'order' => 0, 'class' => '', 'submenu' => '',),
        array('lid' => 2, 'icon' => 'la la-comments-o', 'name' => '默认分类|1,2,3', 'desc' => '默认分类介绍', 'href' => '__forumlist_section__', 'order' => 0, 'class' => '', 'submenu' => '',),
    ));
    xn_nav_menu_slot_add('portalpage', array(
        array('lid' => 1, 'icon' => 'la la-comments', 'name' => '0', 'desc' => '', 'href' => '__portal_section__', 'order' => 0, 'class' => '', 'attr' => '1', 'submenu' => '',),
        array('lid' => 2, 'icon' => 'la la-comments-o', 'name' => '1', 'desc' => '默认分类介绍', 'href' => '__portal_section__', 'order' => 0, 'class' => '', 'attr' => '2', 'submenu' => '',),
        array('lid' => 3, 'icon' => 'la la-comments-o', 'name' => '2', 'desc' => '', 'href' => '__portal_section__', 'order' => 0, 'class' => '', 'attr' => '2', 'submenu' => '',),
    ));
    xn_nav_menu_slot_add('appbar_menu', array(
        array('lid' => 1, 'icon' => 'la la-home', 'name' => '首页', 'title' => '', 'href' => '.', 'order' => 10, 'class' => '', 'attr' => 'data-active=fid-0', 'submenu' => ''),
        array('lid' => 2, 'icon' => 'la la-comments-o', 'name' => '分类', 'title' => '', 'href' => 'bbs.htm', 'order' => 20, 'class' => '', 'attr' => "data-toggle='modal' data-target='#forum'", 'submenu' => ''),
        array('lid' => 3, 'icon' => 'la la-plus', 'name' => '', 'title' => '发帖', 'href' => '__btn_thread_new__', 'order' => 30, 'class' => ' px-3 py-1 rounded-3 bg-gradient', 'submenu' => ''),
        array('lid' => 4, 'icon' => 'la la-plus', 'name' => '', 'title' => '登录', 'href' => '__stately_login_modal__', 'order' => 19, 'class' => ' px-3 py-1 rounded-3 bg-gradient', 'submenu' => ''),
        array('lid' => 5, 'icon' => 'la la-bell-o', 'name' => '消息', 'title' => '', 'href' => '__stately_notice_modal__', 'order' => 40, 'class' => '', 'submenu' => ''),
        array('lid' => 6, 'icon' => 'la la-user', 'name' => '我', 'title' => '', 'href' => 'my.htm', 'order' => 50, 'class' => '', 'attr' => 'data-active=menu-my', 'submenu' => ''),
    ));
    if ($REPLACE_MENU_ITEMS) {
        xn_nav_menu_item_set('primary_menu', array(
            array('lid' => 1, 'icon' => 'la la-home', 'name' => '首页', 'title' => '', 'href' => '.', 'order' => 0, 'class' => '', 'attr' => 'data-active=\'fid-0\''),
            array('lid' => 2, 'icon' => 'la la-comments', 'name' => '话题', 'href' => '__divider_text__', 'order' => 10, 'class' => ''),
            array('lid' => 3, 'icon' => 'la la-comments', 'name' => '话题', 'href' => '__forumlist__', 'order' => 11, 'class' => ''),
            array('lid' => 4, 'icon' => 'la la-plus', 'name' => '发新帖', 'href' => '__btn_thread_new__', 'order' => 100, 'class' => 'menu-link mt-1'),
        ), true);
        xn_nav_menu_item_set('secondary_menu', array(
            array('lid' => 1, 'icon' => 'la la-user', 'name' => '用户', 'href' => '__user_avatar_submenu__', 'order' => 50, 'class' => ''),
            array('lid' => 2, 'icon' => 'la la-user', 'name' => '登录', 'href' => '__stately_login_modal__', 'order' => 100, 'class' => ''),
            array('lid' => 3, 'icon' => 'la la-search', 'name' => '搜索', 'href' => '__stately_search_modal__', 'order' => 10, 'class' => ''),
            array('lid' => 4, 'icon' => 'la la-bell', 'name' => '通知', 'href' => '__stately_notice_modal__', 'order' => 49, 'class' => ''),
        ), true);
        xn_nav_menu_item_set('tertiary_menu', array(
            array('lid' => 1, 'icon' => 'la la-search', 'name' => '搜索', 'href' => '__stately_search_modal__', 'order' => 0, 'class' => ''),
        ), true);
        xn_nav_menu_item_set('user_menu', array(
            array('lid' => 1, 'icon' => 'la la-home', 'name' => '我的主页', 'href' => '__user_brief__', 'order' => 0),
            array('lid' => 2, 'icon' => 'la la-comments', 'name' => '我的帖子', 'href' => url('my-thread'), 'order' => 0),
            array('lid' => 3, 'icon' => 'la la-cog', 'name' => '后台', 'href' => '__admin__', 'order' => 100),
            array('lid' => 4, 'icon' => 'la la-user', 'name' => '退出', 'href' => '__user_logout__', 'order' => 101),
            array('lid' => 5, 'icon' => 'la la-circle-o', 'name' => '——', 'href' => '__divider__', 'order' => 50),
        ), true);
        xn_nav_menu_slot_set('appbar_menu', array(
            array('lid' => 1, 'icon' => 'la la-home', 'name' => '首页', 'title' => '', 'href' => '.', 'order' => 10, 'class' => '', 'attr' => 'data-active=fid-0', 'submenu' => ''),
            array('lid' => 2, 'icon' => 'la la-search', 'name' => '搜索', 'title' => '', 'href' => '__stately_search_modal__', 'order' => 20, 'class' => '', 'attr' => "", 'submenu' => ''),
            array('lid' => 3, 'icon' => 'la la-plus', 'name' => '', 'title' => '发帖', 'href' => '__btn_thread_new__', 'order' => 30, 'class' => ' px-3 py-1 rounded-3 bg-gradient', 'submenu' => ''),
            array('lid' => 4, 'icon' => 'la la-plus', 'name' => '', 'title' => '登录', 'href' => '__stately_login_modal__', 'order' => 19, 'class' => ' px-3 py-1 rounded-3 bg-gradient', 'submenu' => ''),
            array('lid' => 5, 'icon' => 'la la-bell-o', 'name' => '消息', 'title' => '', 'href' => '__stately_notice_modal__', 'order' => 40, 'class' => '', 'submenu' => ''),
            array('lid' => 6, 'icon' => 'la la-user', 'name' => '我', 'title' => '', 'href' => 'my.htm', 'order' => 50, 'class' => '', 'attr' => 'data-active=menu-my', 'submenu' => ''),
        ), true);
    }
}
//*/

message(
    0,
    '</h4></div></div></div></div><style>
    @import "../plugin/abs_theme_stately/view/css/core.css"; 
    @import "../plugin/abs_theme_stately/view/css/theme-default.css"; 
    @import "../plugin/abs_theme_stately/view/css/page-auth.css"; 
    header#header,footer#footer,.col-lg-8.mx-auto>.card{display:none}</style>'
        . '<div class="authentication-wrapper authentication-basic container-p-y">'
        . '<div class="authentication-inner">'
        . '<div class="card">'
        . '<div class="card-body text-center">'
        . '<p class="fs-4 lead">'
        . '感谢您选择 Stately 主题!'
        . '</p>'
        . '<p>'
        . '请为作者买一杯你最喜欢的饮料'
        . $data['panels']['about']['sections']['about_theme']['options']['C0FFEE']['default']
        . $data['panels']['about']['sections']['about_theme']['options']['C0FFEE']['description']
        . '</p>'
        . '<p>'
        . (boolval($conf['url_rewrite_on']) == false ? '请启用伪静态功能，再使用本主题！<b>如遇到部分链接失灵，请在启用伪静态功能后卸载本主题，再重新安装。</b>' : '')
        . (boolval($conf['cache']['enable']) == false ? '建议启用缓存功能！' : '')
        . '<a class="btn btn-primary disabled" id="stately_continue" href="' . url('plugin-setting-abs_theme_stately') . '" >'
        . '好的，进入主题设置'
        . '</a>'
        . '</p>'
        . '</div>'
        . '</div>'
        . '</div>'
        . '</div>'
        . '<script>setTimeout("document.getElementById(\'stately_continue\').classList.remove(\'disabled\')",2000)</script>'
);